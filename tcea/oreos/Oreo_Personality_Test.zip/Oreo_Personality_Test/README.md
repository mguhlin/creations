# Oreo Teaching Personality Quiz

An interactive web-based icebreaker that determines your teaching personality by how you eat an Oreo cookie. Built for TCEA professional learning sessions and adaptable to any classroom, conference, or staff meeting.

Five visual cookie options, each one tied to a teaching archetype. Participants pick the cookie that matches how they actually eat an Oreo, see their personality reveal, and optionally save their response to a Google Sheet. A live results panel shows the room's responses in real time with a bar chart and recent-answer ticker.

---

## What's included

| File | What it does |
|------|--------------|
| `oreo-teaching-personality.html` | The quiz. One self-contained file, about 124 KB, including all CSS, JavaScript, and embedded Oreo images. |
| `Code.gs` | Google Apps Script backend. Saves responses to your Google Sheet and serves aggregated results back to the page. |
| `SETUP.md` | Full deployment instructions, from creating the sheet through hosting the page. |
| `README.md` | This file. |

---

## Quick start

The full walkthrough is in `SETUP.md`. The short version:

1. Create a Google Sheet
2. Paste `Code.gs` into Apps Script (Extensions > Apps Script from the sheet)
3. Deploy as a web app with "Anyone" access
4. Paste the deployment URL into the HTML
5. Open the HTML file in a browser, or host it (GitHub Pages, WordPress iframe, etc.)

About fifteen minutes from start to running session.

---

## Features

- **Five themed cookie choices** with photographic visuals: a whole Oreo, one with a bite taken, one nibbled around the edges, one being dunked in milk with a splash, and two cookies twisted apart showing the cream filling.
- **Personality reveal** with archetype name and full description in TCEA brand styling.
- **Optional response form** capturing name, email, role, session code, and notes. All fields except name are optional.
- **Google Sheets integration** via Apps Script web app. No third-party services, no API keys, your data stays in your Drive.
- **Live results panel** with horizontal bar chart, gold-accent highlight on the leading style, and a recent-answers ticker showing the last eight participants.
- **One-tap "See live results"** button in the hero for navigating to the chart without scrolling.
- **Mobile responsive** down to phone screens.
- **Self-contained HTML** with no build step, no framework, no external dependencies beyond Google Fonts.
- **Accessible** by keyboard. All clickable elements are real buttons, focusable and labeled.

---

## Tech notes

The quiz uses vanilla HTML, CSS, and JavaScript. No frameworks, no build process, no package manager. The whole thing is one file you can open, edit, and ship.

**Why this stack:** It makes the quiz hostable anywhere, embeddable in any LMS or WordPress install, and editable by any teacher who can use a text editor. The trade-off is a slightly larger single-file size (about 124 KB, mostly from the embedded Oreo images as WebP).

**Why Apps Script:** Free, no infrastructure to maintain, no API keys to manage. The script runs under the sheet owner's account and only accepts writes. CORS preflight is avoided by sending POSTs with `Content-Type: text/plain` and a JSON body, which Apps Script parses on the other end.

**Why WebP for the cookie images:** Each cookie is about 20 KB as WebP versus 130 KB as PNG. Total embed savings of about 500 KB. Universally supported by current browsers.

---

## Customizing

Three things are easy to customize without touching the JavaScript logic:

- **Personality descriptions:** Edit the `personalities` object in the HTML's `<script>` block.
- **Colors:** Change the CSS variables at the top of the `<style>` block. `--navy` and `--gold` cascade everywhere.
- **Cookie images:** Replace the base64 data URIs in the `COOKIE_IMAGES` object with your own. The CSS expects square images that work on a white background.

The `SETUP.md` file has line-by-line guidance for adding or removing form fields, which involves coordinated edits to the HTML and `Code.gs`.

---

## Privacy notes

If you're using this with students, especially minors:

- The default form requires a name. Make this optional in the submit handler if you need anonymous responses.
- Skip the email field for students under thirteen, or any time district policy applies.
- Use a session code or pseudonym instead of real names when collecting identifying data is not necessary.
- Data goes to your personal Google Drive, not a third-party service, which usually simplifies district approval.

For adult colleagues at staff meetings, conferences, or professional development sessions, these constraints don't apply. Use real names and emails.

---

## Version history

### 1.5 (current)
- Smarter error handling on the live results panel: detects when the deployed Apps Script is running an older version and shows a specific redeployment message instead of a generic "could not load" error.

### 1.4
- Added a "See live results" call-to-action button in the hero, with smooth scroll to the results panel and a fresh fetch on click.

### 1.3
- New live results panel below the quiz, displaying total responses, a horizontal bar chart with gold highlight on the leading style, and a "Most recent answers" ticker showing the last eight submissions.
- New `?action=results` endpoint added to `Code.gs` for aggregated data delivery.
- Auto-refresh of the results panel after every successful submission.
- Empty state for when no one has answered yet.

### 1.2
- Replaced procedurally generated Oreo SVG graphics with photographic Oreo images that match each option thematically:
  - Choice 1: whole cookie
  - Choice 2: one bite taken
  - Choice 3: multiple nibbles around the edge
  - Choice 4: cookie being dunked with a milk splash
  - Choice 5: two cookies twisted apart showing the cream
- Images stored as base64 WebP data URIs to keep the HTML fully self-contained.
- Slightly larger cookie display size (140 px) to match the increased visual fidelity.

### 1.1
- Earlier procedural SVG cookies refined: tighter scalloped edges, denser ornamentation, twelve four-petal florets, filler dots, surface grain texture, and a double-bordered central oval. (Replaced entirely in 1.2.)

### 1.0
- Initial release.
- Five clickable cookie cards built with CSS pseudo-elements (replaced in 1.1).
- Five personality reveals with TCEA brand styling.
- Save-to-sheet form with optional name, email, role, session code, and notes fields.
- Google Apps Script backend with POST handler and CORS-friendly request handling using `text/plain` content type.
- Auto-creation of the `Responses` sheet tab and header row on first submission.

---

## Credits

Built by Miguel Guhlin, Director of Professional Development at the Texas Computer Education Association (TCEA). Source content adapted from a classic Oreo-eating-style teacher icebreaker that has been circulating in professional development circles for years.

Cookie photography sourced from a reference image and processed for inline embedding. TCEA brand colors (navy `#0A3476` and gold `#FCB040`) and typography (DM Serif Display, DM Sans) are used throughout.

---

## License and reuse

This project is shared for educational use. You're welcome to:

- Run it as-is for your school, district, or organization.
- Modify the personality descriptions, colors, and fields for your audience.
- Translate it into other languages.
- Use it as a starting point for similar interactive icebreakers.

If you build something new from it and share publicly, a credit back to TCEA and the original creator is appreciated but not required.

The Oreo brand name and any Oreo-related trademarks belong to Mondelez International. This is an educational icebreaker and is not affiliated with or endorsed by Mondelez.
