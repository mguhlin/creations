/**
 * Oreo Teaching Personality Quiz - Google Apps Script Endpoint
 * --------------------------------------------------------------
 * POST  -> append a quiz response row to the sheet
 * GET   -> liveness ping
 * GET ?action=results -> return aggregated results JSON
 *
 * Setup:
 *   1. Open your Google Sheet.
 *   2. Extensions > Apps Script.
 *   3. Replace existing code with the contents of this file.
 *   4. Save.
 *   5. Deploy > Manage deployments > pencil icon on your existing deployment
 *      > Version: New version > Deploy. Keeps the same URL.
 *
 * Notes:
 * - POST uses Content-Type "text/plain;charset=utf-8" with JSON body to avoid
 *   CORS preflight (Apps Script web apps don't handle preflight well).
 * - GET requests are simple CORS requests and work from any browser origin.
 */

// ====== CONFIG ======
const SHEET_NAME = 'Responses'; // Tab name where rows are appended
// =====================

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return jsonOut({ status: 'error', message: 'No post data received.' });
    }

    const data = JSON.parse(e.postData.contents);

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

    ensureHeaders(sheet);

    sheet.appendRow([
      new Date(),
      safe(data.name),
      safe(data.email),
      safe(data.role),
      safe(data.session),
      safe(data.choice),
      safe(data.styleName),
      safe(data.archetype),
      safe(data.notes),
      safe(data.submittedAt)
    ]);

    return jsonOut({ status: 'success' });
  } catch (err) {
    return jsonOut({ status: 'error', message: String(err) });
  }
}

/**
 * GET handler. With ?action=results, returns aggregated counts and recent
 * submissions. Otherwise returns a liveness ping.
 */
function doGet(e) {
  const action = e && e.parameter && e.parameter.action;
  if (action === 'results') return getResults();
  return jsonOut({
    status: 'ok',
    message: 'Oreo Teaching Personality endpoint is live.',
    sheet: SHEET_NAME
  });
}

/**
 * Aggregate results: total responses, count per choice (1-5),
 * and the 8 most recent submissions for the live ticker.
 */
function getResults() {
  try {
    const counts = { "1": 0, "2": 0, "3": 0, "4": 0, "5": 0 };
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME);

    if (!sheet || sheet.getLastRow() < 2) {
      return jsonOut({
        status: 'success',
        total: 0,
        counts: counts,
        recent: [],
        asOf: new Date().toISOString()
      });
    }

    const lastRow = sheet.getLastRow();
    const data = sheet.getRange(2, 1, lastRow - 1, 10).getValues();

    for (let i = 0; i < data.length; i++) {
      const choice = String(data[i][5]); // Column 6 = Choice #
      if (counts[choice] !== undefined) counts[choice]++;
    }

    const sorted = data.slice().sort(function(a, b) {
      return new Date(b[0]).getTime() - new Date(a[0]).getTime();
    });
    const recent = [];
    const max = Math.min(8, sorted.length);
    for (let i = 0; i < max; i++) {
      const ts = sorted[i][0];
      recent.push({
        name: String(sorted[i][1] || 'Anonymous'),
        role: String(sorted[i][3] || ''),
        choice: String(sorted[i][5] || ''),
        styleName: String(sorted[i][6] || ''),
        timestamp: ts instanceof Date ? ts.toISOString() : String(ts)
      });
    }

    return jsonOut({
      status: 'success',
      total: data.length,
      counts: counts,
      recent: recent,
      asOf: new Date().toISOString()
    });
  } catch (err) {
    return jsonOut({ status: 'error', message: String(err) });
  }
}

function ensureHeaders(sheet) {
  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      'Timestamp', 'Name', 'Email', 'Role / Grade', 'Session Code',
      'Choice #', 'Style Name', 'Archetype', 'Notes', 'Client Submitted At'
    ]);
    sheet.getRange(1, 1, 1, 10)
      .setFontWeight('bold')
      .setBackground('#0A3476')
      .setFontColor('#FFFFFF');
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, 10);
  }
}

function safe(v) {
  if (v === null || v === undefined) return '';
  return v;
}

function jsonOut(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function testWrite() {
  const fakeEvent = {
    postData: {
      contents: JSON.stringify({
        name: 'Test User',
        email: 'test@example.com',
        role: '5th grade math',
        session: 'TEST',
        choice: '3',
        styleName: 'You Are Meticulous',
        archetype: 'Tidy, orderly, and exact.',
        notes: 'Just testing.',
        submittedAt: new Date().toISOString()
      })
    }
  };
  Logger.log(doPost(fakeEvent).getContent());
}

function testResults() {
  Logger.log(getResults().getContent());
}
