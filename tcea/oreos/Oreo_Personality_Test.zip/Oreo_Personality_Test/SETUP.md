# SETUP.md

Deployment instructions for the Oreo Teaching Personality Quiz.

This guide walks through setting up the Google Sheet, the Apps Script web app, the HTML file, and hosting options. Total time: about fifteen to twenty minutes the first time. No coding experience required.

---

## Before you start

You need:

- A Google account (for the sheet and Apps Script)
- The two files from this project:
  - `oreo-teaching-personality.html` (the quiz)
  - `Code.gs` (the Apps Script backend)
- A text editor (TextEdit, Notepad, VS Code, anything that opens `.html` files)
- Somewhere to host the HTML page when you're done (options listed in Step 7)

---

## Step 1: Create your Google Sheet

1. Open [Google Drive](https://drive.google.com).
2. Click **+ New** then **Google Sheets** to create a blank sheet.
3. Rename the sheet to something like **Oreo Quiz Responses**.
4. Keep this sheet open. You'll launch the Apps Script from inside it so they stay linked.

---

## Step 2: Add the Apps Script

1. Inside your sheet, click **Extensions** in the menu, then **Apps Script**. A new browser tab opens.
2. Delete any sample code in the `Code.gs` file (there's usually a function called `myFunction` already there).
3. Open `Code.gs` from this project, copy everything, and paste it into the Apps Script editor.
4. Click the **Save** icon (or press Ctrl/Cmd + S). Name the project **Oreo Quiz Endpoint** when prompted.

---

## Step 3: Test the Apps Script

Before deploying, run the test function to confirm everything connects properly.

1. In the Apps Script editor, find the function dropdown (next to the **Run** button at the top).
2. Select `testWrite` from the dropdown.
3. Click **Run**.
4. The first time you run any function, Google asks you to authorize it. Approve the permissions:
   - Click **Review permissions**
   - Choose your Google account
   - If a warning appears about an unverified app, click **Advanced**, then **Go to project (unsafe)**, then **Allow**. This is normal for scripts you wrote yourself.
5. Switch back to your sheet. You should see a new tab called **Responses** with one test row in it.
6. Delete that test row when you're done.

If no row appeared, recheck Step 2 (the code paste) and rerun `testWrite`.

---

## Step 4: Deploy the script as a web app

1. In the Apps Script editor, click **Deploy** (top right), then **New deployment**.
2. Click the gear icon next to "Select type" and choose **Web app**.
3. Fill in the form:
   - **Description:** Oreo Quiz v1
   - **Execute as:** Me (your account)
   - **Who has access:** Anyone
4. Click **Deploy**.
5. Approve permissions again if asked.
6. Copy the **Web app URL** that appears. It looks like:
   ```
   https://script.google.com/macros/s/AKfycb.../exec
   ```
7. Paste it somewhere safe (a note, a draft email). You'll use it in the next step.

> **About "Anyone" access:** This makes the script endpoint accept submissions from any browser. It does not give anyone read access to your sheet. The script runs under your account and only writes to the sheet you set it up from.

---

## Step 5: Connect the HTML to your endpoint

1. Open `oreo-teaching-personality.html` in your text editor.
2. Use Find (Ctrl/Cmd + F) to locate this line:
   ```js
   const APPS_SCRIPT_URL = "PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE";
   ```
3. Replace the placeholder with the URL you copied in Step 4. Keep the quotes.
4. Save the file.

Open the HTML file in a browser to test. Pick a cookie, fill in your name, and click **Save my response**. Within a few seconds you should see:
- A new row in your Google Sheet
- The live results panel below the quiz showing your response counted

---

## Step 6: Test the full flow

Before sharing with a real group, run through the whole thing yourself:

1. Open the HTML in your browser.
2. Pick each of the five cookies in turn to confirm the results display correctly.
3. Submit a test response with your name.
4. Confirm the row appears in your sheet.
5. Click **See live results** in the hero. The bar chart should show your response.
6. Click **Refresh** on the results panel. The chart should reload.
7. Delete the test row from your sheet.

---

## Step 7: Host the HTML page

You have four options, from easiest to most polished.

### Option A: Send the file directly
Email the HTML as an attachment, share it via Drive, or drop it in a shared folder. Anyone who downloads and double-clicks it opens the quiz in their browser. Works fine for small groups. Some email systems block HTML attachments though, so test before relying on it.

### Option B: GitHub Pages (free permanent URL)
1. Create a free [GitHub](https://github.com) account if you don't have one.
2. Click **+ New repository** in the top right. Name it something like `oreo-quiz`. Make it public.
3. Upload `oreo-teaching-personality.html` to the repo. Rename it to `index.html` so it loads as the default page.
4. Go to **Settings** > **Pages** in your repo.
5. Under **Source**, select **Deploy from a branch**, branch **main**, folder **/(root)**. Save.
6. Wait a minute or two. Your permanent URL appears at the top of the Pages settings, like:
   ```
   https://yourusername.github.io/oreo-quiz/
   ```

### Option C: Embed in WordPress
Upload the HTML file to your media library or a web folder on your server, then add a **Custom HTML** block in your WordPress page with this code:

```html
<iframe
  src="https://your-domain.com/path/to/oreo-teaching-personality.html"
  width="100%"
  height="2400"
  style="border: 0; max-width: 100%; display: block;"
  loading="lazy"
  title="Oreo Teaching Personality Quiz"
  allow="clipboard-write"
></iframe>
```

If you've already hosted it elsewhere (like GitHub Pages), use that URL in the `src` attribute. The iframe approach is the most reliable way to embed in WordPress because the HTML stays self-contained and isn't affected by your theme's CSS.

### Option D: Direct to your school's LMS
Canvas, Schoology, Google Classroom, and similar platforms typically support embedding via iframe or linking to an external URL. Host the file via Option B, then paste the URL into the LMS announcement, page, or assignment.

---

## Updating after you've deployed

If you change `Code.gs` later (to add fields, edit logic, etc.), redeploy properly so the URL stays the same:

1. Open the Apps Script editor.
2. Click **Deploy** then **Manage deployments** (NOT "New deployment", which gives you a different URL).
3. Click the pencil icon on your existing deployment.
4. In the **Version** dropdown, choose **New version**.
5. Click **Deploy**.

The URL stays identical. Refresh your quiz page.

---

## Customizing for your context

Open the HTML in a text editor. Three things are easy to customize:

### Personality descriptions
Find the `personalities` object in the `<script>` block (roughly three quarters of the way down). Each entry has a `title`, `archetype`, and `text` field. Edit the text in quotes to fit your audience. For example, swap "teacher" for "leader" or "student" depending on who's taking the quiz.

### Colors
The TCEA palette lives at the very top of the `<style>` block as CSS variables:
```css
--navy: #0A3476;
--gold: #FCB040;
```
Change these hex codes to your school's colors. They cascade through the entire page.

### Form fields
You can add, remove, or rename form fields:
1. Edit the `<form id="quizForm">` block in the HTML.
2. Update the `payload` object inside the submit handler so it sends the new fields.
3. Update the `ensureHeaders` function in `Code.gs` so the sheet column matches.
4. Redeploy the Apps Script (see "Updating after you've deployed").

---

## Privacy and student data

If you're running this with minors or under any student data privacy policy (FERPA, COPPA, district rules), take a few extra steps:

- **Make the name optional.** In the submit handler, remove the `if (!payload.name)` check and change the label from "Name" to "Name or initials (optional)."
- **Skip the email field.** Either delete it from the HTML or instruct students to leave it blank.
- **Use a session code instead of names.** Have each student make up a memorable four-letter code so they can find their row later without entering identifiers.
- **Get district sign-off** before recording any identifying information. The fact that data goes to your personal Google Drive (not a third-party vendor) often makes the approval process easier.

For adult colleagues, these constraints don't apply. Real names and emails are fine.

---

## Running it in a session

Allow about ten minutes start to finish:

1. Project the URL or share it via chat, QR code, or email.
2. Give a one-sentence intro: "Pick how you actually eat an Oreo, see your teaching personality, and add your name so we can see the room's results."
3. While people answer, scroll to the live results panel on your projector. Hit **Refresh** every minute or so. The bars update as responses come in.
4. When the room finishes, read the leading style aloud. The gold bar makes it obvious.
5. Use the descriptions as a conversation starter: "How accurate was your result? What does that reveal about how you teach?"

---

## Troubleshooting

### "Could not save right now"
- Confirm the URL is pasted into the HTML and ends in `/exec`
- Open the deployment URL in a new tab. It should return a JSON liveness message. If it asks for authorization, your deployment access is set to "Only myself" instead of "Anyone." Redeploy with the correct setting.
- Make sure the `Responses` sheet tab exists (the script creates it on first POST, but if you deleted it manually, recreate it or rerun `testWrite`).

### "Apps Script needs to be redeployed"
You changed `Code.gs` after the first deployment. Use **Deploy > Manage deployments > pencil icon > Version: New version > Deploy**. The URL stays the same.

### Live results show "Waiting for the first answer" even after submissions
- The script might be writing to a different sheet than expected. Open Apps Script, run `testResults`, and check the log output (View > Logs).
- The page might be showing cached results. Click **Refresh** on the results panel.

### A row was added but it has blank fields
Either the form input had a typo in the `name` attribute, or the payload object in the submit handler doesn't match the field names. Both need to match the column order in `ensureHeaders`.

### The quiz looks broken (no styling, no cookies)
The HTML file is self-contained but it does load Google Fonts from `fonts.googleapis.com`. If you're on a network that blocks Google Fonts, the page will use system fallback fonts (still readable, less stylish). If the cookies don't appear at all, the file may have been corrupted in transit. Re-download and try again.

### You want to delete all responses and start fresh
Open your Google Sheet, select all rows below the header, right-click, and **Delete rows**. The next response will start at row 2 again. No Apps Script changes needed.

---

## What to do if you give up and want help

The whole project is plain HTML, JavaScript, and Google Apps Script (which is JavaScript). Any developer or tech-savvy colleague can pick it up in fifteen minutes. The code is documented and the file count is small (two files plus this guide).

If your school has an instructional technology coach, they can usually walk through this in one sitting.
