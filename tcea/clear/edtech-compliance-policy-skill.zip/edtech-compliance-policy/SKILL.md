---
name: edtech-compliance-policy
description: >
  Generate a self-contained privacy & compliance policy page for an educational
  technology tool. Use whenever the user asks to add GDPR, FERPA, COPPA, Texas
  (SCOPE Act / TEC 32.151), CIPA, accessibility, or "district/legal compliance"
  to a classroom app, widget, game, or web tool — or asks for a privacy policy,
  terms of service, district data privacy addendum, or "combined policy" page like
  drawsplat.org/legal/combined-policy. Triggers on "add GDPR and Texas compliance",
  "make a privacy policy for this tool", "district privacy addendum", "is this
  FERPA/COPPA compliant", "legal page for my ed-tech tool", "SCOPE Act", or any
  request to attach student-privacy documentation to an educational solution.
  Produces a single combined HTML policy file (all CSS embedded, no external
  dependencies except optional Google Fonts) plus an optional short policy notice
  to embed inside the tool itself.
---

# Ed-Tech Compliance Policy Generator

Generate a **self-contained, single-file** privacy & compliance policy page for a K–16 educational technology tool, customized to what the tool actually does. The structure is adapted from the DrawSplat combined-policy model but is **not** copied verbatim — every section is rewritten to match the specific tool's real data behavior.

The cardinal rule: **the policy must describe the tool truthfully.** Do not claim controls a tool does not have, and do not import boilerplate about backends, accounts, or storage modes that the tool does not use. For most self-contained client-side classroom tools, the honest story is *stronger and shorter* than DrawSplat's, because there is no server and no data collection at all.

---

## Step 1 — Run the data-behavior inventory FIRST

Before writing a single line of policy, determine exactly what the tool does with data. Inspect the tool's source (or ask the user) and answer every question below. The answers drive which sections are included and what each one says.

1. **Server?** Does the tool make any network request that sends user input anywhere? (fetch/XHR/form POST/websocket/beacon/analytics/font CDN/image CDN)
2. **Accounts/login?** Any sign-in, SSO, email, or password?
3. **Persistence?** `localStorage`, `sessionStorage`, IndexedDB, cookies, URL hash/query state, or downloadable export files?
4. **PII entry?** Can a student type or upload a name, photo, audio, location, or other identifying content? Where does it go?
5. **Third parties?** Any external script, font, image, ad, tracker, embed, or API?
6. **AI calls?** Does it call an LLM/API (e.g. the Anthropic API in an artifact)? If so, what is sent and is it student PII?
7. **Hosting?** Where will it live — a static host, GitHub Pages, Google Sites iframe, district server?
8. **Audience age?** Grade/age bands; does it knowingly involve under-13 users?

Record the answers; you will reference them in the "What this tool actually does" snapshot, which is the spine of the whole document.

**Classification shortcut:**
- **Tier A — Fully client-side, zero data egress** (no server, no accounts, no third-party calls; state only in memory / URL hash / localStorage that never leaves the browser). This is the common case for self-contained HTML tools. The policy is short and the privacy posture is maximal.
- **Tier B — Client-side + a font/CDN or optional export to a user-chosen cloud.** Mostly Tier A, but disclose the one or two external requests honestly.
- **Tier C — Has a backend, accounts, AI API calls, or analytics.** Use the full DrawSplat-style structure including storage modes, subprocessors, retention, breach SOP, and security review. Do not understate.

---

## Step 2 — Assemble the combined policy page

Produce ONE HTML file (e.g. `legal/combined-policy.html` or `<tool>-policy.html`) with a contents list at top and these sections. Include every section marked **[always]**; include **[tier]** sections only when they apply.

### Sections

1. **Snapshot / "What this tool actually does"** [always] — the honest one-paragraph + bullet inventory from Step 1. For Tier A, lead with the strongest true claims: no account, no server, no data collection, no tracking, works offline, nothing leaves the browser.

2. **Short Version** [always] — 6–10 plain-language bullets a busy administrator or parent can read in 30 seconds. Mirror the real behavior. Typical Tier-A bullets:
   - No student accounts and no login.
   - No data is sent to any server; the tool runs entirely in the browser.
   - No student data is collected, sold, shared, or used for advertising or AI training.
   - No third-party trackers, ads, or analytics.
   - The only stored data is [local progress in the browser / state in the page URL], which never leaves the device.
   - Works fully offline once loaded.
   - Teachers/schools control how and where the tool is shared.

3. **Terms of Service** [always] — who may use it, acceptable use, ownership of any user-created content, license, and an as-is / no-warranty clause. Keep it short for simple tools.

4. **Privacy Policy** [always] — define "student personal information"; state precisely what data is and is not collected, how (if at all) it is processed, and that the use is limited to the educational purpose. For Tier A, this section largely says "none of the above applies because no data is collected or transmitted."

5. **Student Privacy Commitments (P-R-O-T-E-C-T)** [always] — Parental Rights, Retention & Deletion, Opt-out, Transparency, Encryption/Security, Consent & Age, Third-party Management. For each, state the true posture. For Tier A, deletion = "clear your browser data or close the tab"; third-party management = "none."

6. **GDPR Compliance Summary** [always when GDPR requested or audience may include EU/UK] — lawful basis, data-subject rights (access, rectification, erasure, portability, objection, restriction), data minimization, and (critically for Tier A) the fact that with no collection/processing of personal data there is no controller-side dataset to subject to a request; if any localStorage exists, document that the user controls it locally. Name the school/district as the controller for any classroom deployment and the tool author as, at most, a processor with no access to data.

7. **Texas Compliance Explainer** [always when Texas requested] — plain-language mapping to: **SCOPE Act** (note enjoined portions are not implemented; for tools with no accounts, age-registration provisions are addressed by having no account to register), **FERPA**, **COPPA** (district-as-agent consent model for under-13), **TEC §32.151–32.156** (district↔vendor data agreements), and **CIPA** (a network-level school obligation the tool supports but does not replace). State honestly which provisions are N/A because the tool collects nothing.

8. **District Data Privacy Addendum** [tier B/C, or on request] — signature-ready template with parties, approved educational purpose, deployment configuration, data-use commitments, retention/return/destruction, security & breach notice, FERPA/COPPA school-official language, subprocessors table, signatures. For Tier A include a short version that mostly attests "no student data is collected or transmitted by this tool."

9. **Accessibility Statement (VPAT-lite)** [always] — WCAG 2.1 AA aim, a conformance table per UI area, specifics on keyboard nav, screen readers, contrast & color (never color-alone), motion (`prefers-reduced-motion`), zoom/font scaling, audio toggles, forms. List **known gaps** honestly — do not claim full conformance without an audit.

10. **Subprocessors / Third-Party Inventory** [tier B/C] — table of any external provider, purpose, data exposed, and whose contract governs. For Tier A, state "None — this tool makes no third-party requests."

11. **Security Practices & Breach Notice** [tier C; abbreviated for B] — HTTPS, CSP, encryption at rest/in transit, least privilege, audit logging, 72-hour breach notice, annual review. Omit or shrink to "served over HTTPS; no server-side data store" for Tier A.

12. **Contact, Requests & Policy Changes** [always] — where to direct privacy requests (for classroom use: the teacher/school/district that deployed the tool first), acknowledge within 10 school days / complete within 30 calendar days when feasible, and an updated-date + version-history table.

### Legal-accuracy guardrails (do not violate)

- **Not legal advice.** Every page must state plainly that it is not legal advice and that district counsel should review against the local Data Sharing Agreement (DSA/DPA).
- **No invented certifications.** Never claim SOC 2, ISO 27001, an independent audit, or a completed VPAT unless the user confirms it exists.
- **No invented contacts.** Use a clearly-marked placeholder like `[deployment owner / privacy contact — fill in before publishing]` rather than a fabricated email.
- **Truth over completeness.** If unsure whether the tool does something, ask or inspect — never assume a control exists.
- **Enjoined-law honesty.** For SCOPE, note that some provisions have been challenged/enjoined and only currently-in-force requirements are reflected.
- **Don't reproduce DrawSplat text.** Use it as a structural reference only; write original prose tailored to this tool.

---

## Step 3 — Optional in-tool notice

For tools where a "Privacy" link belongs in the UI, also produce a compact notice (a few sentences) the tool can show in a footer, an about/info modal, or a collapsible panel — plus a link to the full combined policy page. Keep it consistent with the full policy. Example for Tier A:

> **Privacy:** This tool runs entirely in your browser. It has no accounts, sends no data to any server, uses no trackers or ads, and never uses student work to train AI. Any saved progress stays on this device. Full policy: [combined-policy.html].

---

## Step 4 — Styling & output

- **Self-contained:** all CSS embedded in one `<style>` block; no external frameworks. Google Fonts CDN is the only permitted external dependency, and if the parent tool is Tier A "zero egress," prefer a system font stack so the policy page itself also makes no external request — and say so.
- **Match the tool's look** when a house style/skill is in play (e.g. apply the project's design tokens). Otherwise use clean, high-contrast, readable defaults at WCAG AA.
- **Printable:** include a "Print / Save as PDF" affordance (`window.print()`) and print-friendly CSS, since district reviewers print these.
- **Accessible:** semantic headings, a table of contents with in-page anchors, `scroll-margin-top` on sections, visible focus outlines, contrast ≥ 4.5:1.
- **Place output** in `/mnt/user-data/outputs/` and present it. If the tool already has a `legal/` convention, name it `combined-policy.html`.

---

## Quick checklist before delivering

- [ ] Ran the Step-1 data inventory and classified Tier A/B/C
- [ ] Snapshot + Short Version reflect the tool's REAL behavior (no imported boilerplate)
- [ ] GDPR section present (if requested or EU/UK audience possible)
- [ ] Texas section maps SCOPE / FERPA / COPPA / TEC 32.151 / CIPA, with enjoined-provision honesty
- [ ] Accessibility statement lists real known gaps
- [ ] "Not legal advice" + "district counsel should review" stated
- [ ] No invented audits, certifications, contacts, or controls
- [ ] Placeholders used for deployment-specific contact/retention/consent
- [ ] Version-history table with today's date
- [ ] Single self-contained file; printable; accessible; placed in outputs
- [ ] Optional in-tool privacy notice provided if the tool has a UI
