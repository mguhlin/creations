# ShareSpace Setup

A self-hosted, Padlet-style submission board. Participants upload files (any format, up to 25 MB) plus a short reflection. Files land in Google Drive organized by category. The board shows everything in a masonry grid with newest first. An admin page lets you edit reflections or delete submissions.

Total setup time: about ten minutes.

## What's in this folder

| File          | Purpose                                                                              |
| ------------- | ------------------------------------------------------------------------------------ |
| `code.gs`     | Google Apps Script backend                                                           |
| `submit.html` | Upload form. Auto-redirects to `board.html` after a successful submission.           |
| `board.html`  | Public canvas with category filters and auto-refresh every 60 seconds                |
| `admin.html`  | Passcode-protected page for editing reflections and deleting submissions             |

## Categories — already configured

The four files ship configured with these categories:

- Amazing Prompts
- Gemini Images
- ChatGPT Images
- Claude Images
- Miscellaneous

If you want different ones, edit them in **all four files** before deploying. They must match exactly:

- `code.gs` — `ALLOWED_CATEGORIES` array near the top
- `submit.html` — the `<select id="category">` block (look for the `<option>` lines)
- `board.html` — the `CATEGORIES` constant inside the `<script>` block
- `admin.html` — the `CATEGORIES` constant inside the `<script>` block

If the lists drift apart, submissions get rejected with "Please choose a category from the list."

## Step 1 — Create the Apps Script project

1. Go to [script.google.com](https://script.google.com) and click **New project**.
2. Rename the project (top left) — for example, `ShareSpace`.
3. Delete the placeholder code in `Code.gs` and paste in the contents of `code.gs` from this folder.
4. Save (Ctrl+S or Cmd+S).

## Step 2 — Run setupNow once

1. In the function dropdown at the top of the editor, select `setupNow`.
2. Click **Run**.
3. Authorize when prompted. If you see "Google hasn't verified this app," click **Advanced** > **Go to (project name) (unsafe)** > **Allow**. This is normal for personal Apps Script projects.
4. Verify in your Drive: a folder named `ShareSpace` (or whatever you set `PROJECT_NAME` to in `code.gs`) with a subfolder for each category, plus a Google Sheet matching `SHEET_NAME`.

## Step 3 — Set the admin passcode

1. Click the gear icon on the left side of the editor (Project Settings).
2. Scroll to **Script Properties** > **Edit script properties** > **Add script property**.
3. Property: `ADMIN_PASSCODE`
4. Value: any passcode you choose. This is what you'll type into the admin page.
5. Save.

If you skip this step, the admin page will tell you the passcode isn't configured. Submissions and the public board still work.

## Step 4 — Deploy as a web app

1. Click **Deploy** > **New deployment**.
2. Click the gear next to "Select type" and choose **Web app**.
3. Fill in:
   - Description: a label like `v1`
   - Execute as: **Me (your.email@domain.com)**
   - Who has access: **Anyone**
4. Click **Deploy**.
5. Authorize again if asked.
6. Copy the **Web app URL** (ends in `/exec`).

**Important:** "Who has access: Anyone" is required. If you set it to "Only myself" or "Anyone with Google account", the form will not work for participants.

## Step 5 — Verify the deployment with a quick health check

Paste your Web app URL into the browser address bar, and add `?action=ping` to the end. So if your URL is:

```
https://script.google.com/macros/s/AKfy.../exec
```

Visit:

```
https://script.google.com/macros/s/AKfy.../exec?action=ping
```

You should see a JSON response that looks roughly like:

```json
{"ok":true,"project":"ShareSpace","categories":["Amazing Prompts", ...],"passcodeSet":true,"time":"2026-04-30T..."}
```

If you see this, your backend is reachable and configured. If you see an HTML error page or "Sorry, the file you have requested does not exist," then the deployment access isn't set to **Anyone** — go back to Step 4.

If `passcodeSet` is `false`, go back to Step 3.

## Step 6 — Wire the URL into the three HTML files

In `submit.html`, `board.html`, and `admin.html`, find this line near the top of the `<script>` block:

```javascript
const SCRIPT_URL = 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE';
```

Replace the placeholder with your Web app URL. Save all three files.

## Step 7 — Host the files

Keep `submit.html`, `board.html`, and `admin.html` together in the same folder. The post-submission redirect uses a relative link (`board.html`) and depends on this.

Hosting options: WordPress media library, GitHub Pages, WP Engine static folder, or any static host.

For embedding inside WordPress, use a Custom HTML block:

```html
<iframe src="https://yourdomain.com/path/to/sharespace/submit.html"
        width="100%" height="1100" frameborder="0"
        style="border: none;"></iframe>
```

Suggested heights:
- `submit.html`: 1100–1200
- `board.html`: 1500–1800
- `admin.html`: standalone page, not embedded

If you embed `submit.html` and want the redirect to take users to a *different* WordPress page hosting `board.html`, change `BOARD_URL` near the top of `submit.html`'s script block from `'board.html'` to the absolute URL.

## Step 8 — Test it

1. Open `submit.html`. Submit a small test image with your name, email, a category, and a reflection.
2. Watch the success panel count down from 3 and redirect to the board.
3. Confirm your test entry appears with its reflection underneath.
4. Open `admin.html`. Enter your passcode. Edit the reflection, save it. Within 60 seconds the board should reflect the change.
5. From admin, delete the test entry. Confirm it's gone from the board (the file goes to Drive trash, recoverable for 30 days).

## Updating code.gs later — important

If you change `code.gs` after deploying, you **must** redeploy as a new version, or the live URL keeps running the old code. This is the single most common reason "I edited Code.gs but nothing changed":

1. **Deploy** > **Manage deployments**
2. Click the **pencil icon** on your existing deployment
3. Under **Version**, choose **New version**
4. Click **Deploy**

The Web app URL stays the same. The HTML files keep working — no need to update them.

## Troubleshooting

| Symptom                                                                     | Likely cause                                                                                  |
| --------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| "Backend returned an unexpected response"                                   | Deployment access is not set to "Anyone", or you didn't redeploy after editing `code.gs`      |
| "Could not reach the backend"                                               | `SCRIPT_URL` typo, or no internet connection                                                  |
| "Please choose a category from the list"                                    | Category lists in the four files don't match exactly                                          |
| Admin says "Invalid passcode" even when you typed it right                  | `ADMIN_PASSCODE` not set in Script Properties, or you have trailing whitespace                |
| Admin says "Admin passcode not configured"                                  | Set `ADMIN_PASSCODE` in Project Settings > Script Properties (Step 3)                         |
| `?action=ping` returns HTML instead of JSON                                 | Deployment access is "Only myself" or "Anyone with Google account" — change to "Anyone"       |
| Edited `code.gs` but behavior didn't change                                 | You must redeploy as **New version** (see above) — the URL stays the same but runs old code  |
| Thumbnails don't show on the board                                          | Workspace policy blocks public sharing — files fall back to domain-only and won't preview     |
| Submission fails with no clear error                                        | Open browser devtools > Console tab to see the actual error text                              |

## What participants see for each file format

| Type                                       | What participants see                                              |
| ------------------------------------------ | ------------------------------------------------------------------ |
| Images (PNG, JPG, GIF, WebP, HEIC, etc.)   | Inline thumbnail, click to enlarge in lightbox                     |
| PDFs                                       | First-page thumbnail, click "Open" for full doc in Drive           |
| Videos (MP4, MOV, M4V, WebM, AVI, etc.)    | Inline player via Drive's preview iframe                           |
| Audio (MP3, M4A, WAV, etc.)                | Inline player via Drive's preview iframe                           |
| Text files (.txt, .md, .json)              | Content shown inline if under 50 KB, with "Show more" toggle       |
| Office docs (DOCX, PPTX, XLSX)             | File-icon card with extension label, click "Open" for Drive        |
| Anything else                              | File-icon card, click "Open" for Drive                             |

## Limits and behaviors

- File size: 25 MB hard cap, enforced both client-side and server-side.
- Reflection: 500 character cap, optional.
- Email addresses are captured but never displayed on the public board. They are visible on the admin page only.
- Board auto-refreshes every 60 seconds. Manual refresh button available.
- Deleting from admin moves the file to Drive trash (recoverable for 30 days) and removes the row from the Sheet.

## Security note

The admin page is protected by a passcode you set in Script Properties. The passcode is sent over HTTPS in the request body. This is classroom-grade security, not bank-grade. Pick something not trivially guessable, and don't post the admin URL publicly. The submit and board pages have no authentication, by design.

## Reusing for a new project

Copy the entire folder. For the new copy:

1. Edit categories in all four files
2. Edit `PROJECT_NAME` and `SHEET_NAME` in the new `code.gs`
3. Create a fresh Apps Script project (don't reuse the old one — it points at your old Drive folder)
4. Set a new admin passcode
5. Deploy and paste the new URL into the new HTML files

Each project is fully self-contained: its own backend, Drive folder, sheet, and passcode.

---

*Developed by Miguel Guhlin — [blog.tcea.org](https://blog.tcea.org) | Social: [mguhlin.org](https://mguhlin.org)*
