# ShareSpace - Project Instructions

A self-hosted, Padlet-style submission board. Participants upload files of any format up to 25 MB along with a short reflection. Files land in a Google Drive folder organized by category, and a public board displays everything in a masonry grid with the newest at the top. A passcode-protected admin page lets you edit reflections or delete submissions.

This is a generic, reusable template. Configure it once for a project, then copy the folder for your next project and reconfigure.

## What you get

| File           | Purpose                                                                              |
| -------------- | ------------------------------------------------------------------------------------ |
| `Code.gs`      | Google Apps Script backend. Handles uploads, serves the JSON feed, admin endpoints.  |
| `submit.html`  | The upload form. Auto-redirects to `board.html` after a successful submission.       |
| `board.html`   | The public canvas. Filter pills by category, masonry grid, auto-refresh.             |
| `admin.html`   | Passcode-protected management page for editing reflections and deleting submissions. |

All four files include a small attribution line at the bottom: *Developed by Miguel Guhlin - blog.tcea.org | Social: mguhlin.org*.

## Setup, in order

### 1. Configure the Apps Script project

Open `Code.gs` in any editor and edit the CONFIG block at the top:

```javascript
const PROJECT_NAME = 'ShareSpace';                  // Drive folder name
const SHEET_NAME = 'ShareSpace Submissions Log';    // Logging spreadsheet name
const ALLOWED_CATEGORIES = [
  'General',
  'Category 1',
  'Category 2',
  'Category 3',
  'Category 4',
  'Category 5'
];
```

Pick a project name that means something for your context (for example, `Spring Cohort ShareSpace` or `District PD ShareSpace`). Pick categories that fit your content (modules, departments, weeks, themes, whatever).

### 2. Match the categories in the three HTML files

The category list lives in four places. They must all match exactly.

In `submit.html`, find the `<select id="category">` block and update the `<option>` values:

```html
<option value="General">General</option>
<option value="Category 1">Category 1</option>
<!-- ...etc... -->
```

In `board.html`, find the `CATEGORIES` constant in the `<script>` block:

```javascript
const CATEGORIES = [
  'General',
  'Category 1',
  // ...etc...
];
```

You can optionally add shorter labels for the filter pills in `CATEGORY_LABELS` right below.

In `admin.html`, find the `CATEGORIES` constant in the `<script>` block (same format as board.html).

If the four lists drift out of sync, submissions will be rejected with a "Please choose a category from the list" error.

### 3. Create the Apps Script project

1. Go to [script.google.com](https://script.google.com), click **New project**.
2. Rename the project (top-left corner) to match your deployment, for example `Spring Cohort ShareSpace`.
3. Delete the placeholder `Code.gs` and paste in your edited `Code.gs`.
4. Save (Ctrl+S or Cmd+S).

### 4. Run setupNow once

1. In the function dropdown at the top of the editor, select `setupNow`.
2. Click **Run**.
3. Google asks for authorization. Click through the prompts. If you see "Google hasn't verified this app," click **Advanced**, then **Go to (project name) (unsafe)**, then **Allow**. This is normal for Apps Script projects you write yourself.
4. After it runs, check your Drive. You should have a folder named whatever you set `PROJECT_NAME` to, with subfolders for each category. You should also have a spreadsheet matching `SHEET_NAME`.

### 5. Set the admin passcode

1. Click the gear icon on the left side of the Apps Script editor (Project Settings).
2. Scroll to **Script Properties**.
3. Click **Edit script properties**, then **Add script property**.
4. Property: `ADMIN_PASSCODE`
5. Value: a passcode of your choice. Pick something that's not trivially guessable. This is what you type into the admin page.
6. Click **Save script properties**.

### 6. Deploy as a web app

1. Click **Deploy** (top right), then **New deployment**.
2. Click the gear next to "Select type" and choose **Web app**.
3. Fill in:
   - Description: a version label (for example, `v1`)
   - Execute as: `Me (your.email@domain.com)`
   - Who has access: `Anyone`
4. Click **Deploy**.
5. Copy the **Web app URL**. It will look like `https://script.google.com/macros/s/AKfy.../exec`.

### 7. Wire the URL into the three HTML files

Open each HTML file. Near the top of the `<script>` block you'll find:

```javascript
const SCRIPT_URL = 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE';
```

Replace the placeholder with the URL you copied. Save all three files.

### 8. Host the files

Keep `submit.html`, `board.html`, and `admin.html` together in the same folder (this is what makes the post-submission redirect work, since `submit.html` uses a relative link to `board.html`).

Hosting options:
- WordPress media library (upload all three, link from a regular page)
- GitHub Pages (free, easy, lets you keep them in a repo)
- WP Engine static folder (`/wp-content/uploads/sharespace/`)
- Any other static host

For embedding inside a WordPress page, use a Custom HTML block:

```html
<iframe src="https://yourdomain.com/path/to/sharespace/submit.html"
        width="100%" height="1100" frameborder="0"
        style="border: none;"></iframe>
```

Suggested heights:
- `submit.html`: 1100-1200 (the format hints and reflection field add space)
- `board.html`: 1500-1800 (depends on how many submissions you expect)
- `admin.html`: better as a standalone bookmarked page than embedded - more room to work

Important: the post-submission redirect to `board.html` works best when both files live at the same URL path. If you embed `submit.html` in a WordPress page, the redirect happens inside the iframe, which still works but feels slightly contained. If that bothers you, change `BOARD_URL` near the top of the script block in `submit.html` to an absolute URL pointing to the WordPress page that embeds `board.html`.

### 9. Test it

1. Open `submit.html`. Submit a small test image with your name, email, and a short reflection.
2. Watch the success panel: it counts down from 3, then redirects to the board.
3. Verify your test entry appears in the masonry grid with the reflection underneath.
4. Open `admin.html`. Enter your passcode. Edit the test reflection, save it. Refresh the board (or wait 60 seconds for auto-refresh) to confirm it changed.
5. From admin, delete the test entry. Confirm it disappears from the board and from Drive (it goes to Drive trash, recoverable for 30 days).
6. Check the Sheet. You should see one row that's now gone, leaving the headers in place.

## Updating Code.gs later

If you change `Code.gs` for any reason, you must redeploy:

1. Click **Deploy** > **Manage deployments**.
2. Click the pencil icon on the existing deployment.
3. Under **Version**, choose **New version**.
4. Click **Deploy**.

The web app URL stays the same, so the HTML files keep working.

## Reusing this template for a new project

To spin up a second deployment for a different project, copy the entire folder, then for the new copy:

1. Edit the four spots that name categories (`Code.gs`, `submit.html`, `board.html`, `admin.html`)
2. Edit `PROJECT_NAME` and `SHEET_NAME` in the new `Code.gs`
3. Create a new Apps Script project (don't reuse the old one - that would point at your old Drive folder)
4. Set a new admin passcode in the new project's Script Properties
5. Deploy and paste the new URL into the new HTML files

Each project is its own self-contained backend with its own Drive folder, sheet, and passcode. Nothing is shared.

## What participants see for each file format

| Type                                       | What participants see                                              |
| ------------------------------------------ | ------------------------------------------------------------------ |
| Images (PNG, JPG, GIF, WebP, HEIC, etc.)   | Inline thumbnail, click to enlarge in lightbox                     |
| PDFs                                       | First-page thumbnail, click "Open" for full doc in Drive           |
| Videos (MP4, MOV, M4V, WebM, AVI, etc.)    | Inline player via Drive's preview iframe                           |
| Audio (MP3, M4A, WAV, etc.)                | Inline player via Drive's preview iframe                           |
| Text files (.txt, .md, .json)              | Content shown inline if under 50 KB, with "Show more" toggle       |
| Office docs (DOCX, PPTX, XLSX)             | File-icon card with extension label, click "Open" for Drive        |
| Anything else                              | File-icon card, click "Open" for Drive                             |

These hints are also displayed inline on the submission form so participants know what to expect.

## Where things live

| Where                                                     | What                                                                                       |
| --------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| Drive: `[PROJECT_NAME]/[category]/`                       | The actual files. Filenames prefixed with timestamp + sanitized submitter name             |
| Google Sheet `[SHEET_NAME]`                               | One row per submission (timestamp, name, email, category, file metadata, reflection)       |
| Script Properties                                         | Folder ID, Sheet ID, and `ADMIN_PASSCODE`                                                  |

## Limits and behaviors

- File size: 25 MB hard cap, enforced both client-side and server-side.
- Reflection: 500 character cap, optional.
- All file formats accepted. Mobile devices can submit directly from camera or file picker.
- Files are made viewable to "Anyone with the link" so the board can render thumbnails. If your Workspace blocks public sharing, the script falls back to domain-only sharing - thumbnails will only work for people in your domain.
- Email addresses are captured but never displayed on the public board. They are visible on the admin page only.
- Board auto-refreshes every 60 seconds. Manual refresh button is one click.
- Deleting from admin moves the file to Drive trash (recoverable for 30 days) and removes the row from the Sheet.
- Editing a reflection updates the Sheet immediately. The board picks up the change on the next auto-refresh (within 60 seconds).

## Security note

The admin page is protected by a passcode you set in Script Properties. The passcode is sent over HTTPS in the request body (not in the URL). This is classroom-grade security, not bank-grade. Pick a passcode that's not trivially guessable, and don't post the admin URL publicly. The submit and board pages have no authentication, by design - anyone with their URLs can submit and view.

## Customization knobs

Inside the HTML files (CSS variables at the top of each `<style>` block):
- All colors live in `:root` as CSS custom properties. Change navy, gold, and the variants to rebrand.
- Fonts are loaded from Google Fonts. Replace the link in `<head>` to change them.

Inside `Code.gs`:
- `MAX_FILE_SIZE_BYTES` - file size cap
- `MAX_REFLECTION_CHARS` - reflection length cap
- `MAX_TEXT_INLINE_BYTES` - threshold for showing text content inline on the board

If you change `MAX_FILE_SIZE_BYTES` or `MAX_REFLECTION_CHARS` in `Code.gs`, also change the matching constants (`MAX_BYTES`, `MAX_REFLECTION`) at the top of the script block in `submit.html` and `admin.html`.

---

*Developed by Miguel Guhlin - [blog.tcea.org](https://blog.tcea.org) | Social: [mguhlin.org](https://mguhlin.org)*
