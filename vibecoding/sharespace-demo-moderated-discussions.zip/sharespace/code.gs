/*******************************************************
 * ShareSpace Moderated - Google Apps Script backend
 * Static front end: index.html, Submit.html, Admin.html
 *******************************************************/

const PROJECT_NAME = 'ShareSpace';
const SHEET_NAME = 'ShareSpace Submissions';
const DISCUSSION_SHEET_NAME = 'ShareSpace Discussion Replies';
const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024;
const MAX_REFLECTION_CHARS = 700;
const MAX_TITLE_CHARS = 100;
const MAX_TEXT_INLINE_BYTES = 50 * 1024;

const ALLOWED_CATEGORIES = [
  'Amazing Prompts',
  'Gemini Images',
  'ChatGPT Images',
  'Claude Images',
  'Student Projects',
  'Staff Examples',
  'Miscellaneous'
];

const HEADERS = [
  'id', 'timestamp', 'status', 'name', 'email', 'category', 'title', 'reflection',
  'fileName', 'mimeType', 'fileId', 'fileUrl', 'textContent', 'updatedAt'
];

const DISCUSSION_HEADERS = [
  'id', 'timestamp', 'status', 'topicId', 'topicTitle', 'parentId', 'name', 'email', 'text', 'updatedAt'
];
const MAX_DISCUSSION_REPLY_CHARS = 1200;

function setupNow() {
  const folder = getOrCreateRootFolder();
  ALLOWED_CATEGORIES.forEach(function(category) { getOrCreateCategoryFolder(category); });
  const sheet = getOrCreateSheet();
  ensureHeaders(sheet);
  PropertiesService.getScriptProperties().setProperty('PROJECT_READY', 'true');
  return 'Setup complete for ' + PROJECT_NAME + '. Folder: ' + folder.getUrl();
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  const action = String(p.action || 'list');
  try {
    if (action === 'ping') return jsonResponse(ping_());
    if (action === 'list') return publicList_();
    if (action === 'discussionReplies') return discussionReplies_(p);
    if (action === 'adminList') return adminList_(p);
    return jsonResponse({ ok: false, error: 'Unknown action.' });
  } catch (err) {
    return jsonResponse({ ok: false, error: errorText_(err) });
  }
}

function doPost(e) {
  const p = (e && e.parameter) || {};
  const action = String(p.action || 'submit');
  try {
    if (action === 'submit') return submitNew_(p);
    if (action === 'discussionReply') return submitDiscussionReply_(p);
    if (action === 'adminList') return adminList_(p);
    if (action === 'setStatus') return setStatus_(p);
    if (action === 'update') return updateSubmission_(p);
    if (action === 'delete') return deleteSubmission_(p);
    if (action === 'setModeration') return setModeration_(p);
    return jsonResponse({ ok: false, error: 'Unknown action.' });
  } catch (err) {
    return jsonResponse({ ok: false, error: errorText_(err) });
  }
}

function ping_() {
  return {
    ok: true,
    project: PROJECT_NAME,
    categories: ALLOWED_CATEGORIES,
    moderationEnabled: isModerationEnabled_(),
    passcodeSet: !!getAdminPasscode_(),
    time: new Date().toISOString()
  };
}

function publicList_() {
  const rows = readRows_().filter(function(item) { return item.status === 'approved'; });
  rows.sort(function(a, b) { return new Date(b.timestamp) - new Date(a.timestamp); });
  return jsonResponse({ ok: true, moderationEnabled: isModerationEnabled_(), submissions: rows.map(publicShape_) });
}

function submitNew_(p) {
  const name = clean_(p.name || 'Anonymous').slice(0, 80) || 'Anonymous';
  const email = clean_(p.email || '');
  const category = clean_(p.category || '');
  const title = clean_(p.title || '').slice(0, MAX_TITLE_CHARS);
  let reflection = clean_(p.reflection || '').slice(0, MAX_REFLECTION_CHARS);
  const fileName = clean_(p.fileName || 'upload');
  const mimeType = clean_(p.mimeType || 'application/octet-stream');
  let fileData = String(p.fileData || '');

  if (!title) return jsonResponse({ ok: false, error: 'Title is required.' });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return jsonResponse({ ok: false, error: 'A valid email is required.' });
  if (ALLOWED_CATEGORIES.indexOf(category) === -1) return jsonResponse({ ok: false, error: 'Please choose a category from the list.' });
  if (!fileData) return jsonResponse({ ok: false, error: 'Please choose a file to upload.' });

  if (fileData.indexOf(',') !== -1 && fileData.indexOf('base64') !== -1) fileData = fileData.split(',')[1];
  const bytes = Utilities.base64Decode(fileData);
  if (!bytes || bytes.length === 0) return jsonResponse({ ok: false, error: 'The uploaded file appears to be empty.' });
  if (bytes.length > MAX_FILE_SIZE_BYTES) return jsonResponse({ ok: false, error: 'File is larger than 25 MB.' });

  const blob = Utilities.newBlob(bytes, mimeType, fileName);
  const folder = getOrCreateCategoryFolder(category);
  const now = new Date();
  const safeName = now.getTime() + '__' + sanitize_(title) + '__' + sanitize_(fileName);
  const file = folder.createFile(blob.setName(safeName));

  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (err) {
    try { file.setSharing(DriveApp.Access.DOMAIN_WITH_LINK, DriveApp.Permission.VIEW); } catch (ignore) {}
  }

  let textContent = '';
  if ((mimeType.indexOf('text/') === 0 || mimeType === 'application/json' || /\.(txt|md|json|csv)$/i.test(fileName)) && bytes.length < MAX_TEXT_INLINE_BYTES) {
    try { textContent = blob.getDataAsString(); } catch (ignore2) {}
  }

  const status = isModerationEnabled_() ? 'pending' : 'approved';
  const item = {
    id: Utilities.getUuid(),
    timestamp: now.toISOString(),
    status: status,
    name: name,
    email: email,
    category: category,
    title: title,
    reflection: reflection,
    fileName: fileName,
    mimeType: mimeType,
    fileId: file.getId(),
    fileUrl: file.getUrl(),
    textContent: textContent,
    updatedAt: now.toISOString()
  };

  appendRow_(item);
  return jsonResponse({ ok: true, status: status, moderationEnabled: isModerationEnabled_(), id: item.id });
}

function adminList_(p) {
  const auth = checkAdmin_(p);
  if (auth) return jsonResponse({ ok: false, error: auth });
  const rows = readRows_();
  rows.sort(function(a, b) { return new Date(b.timestamp) - new Date(a.timestamp); });
  return jsonResponse({ ok: true, moderationEnabled: isModerationEnabled_(), categories: ALLOWED_CATEGORIES, submissions: rows });
}

function setStatus_(p) {
  const auth = checkAdmin_(p);
  if (auth) return jsonResponse({ ok: false, error: auth });
  const id = clean_(p.id || '');
  const status = clean_(p.status || '');
  if (['pending', 'approved', 'hidden'].indexOf(status) === -1) return jsonResponse({ ok: false, error: 'Invalid status.' });
  const updated = updateRowById_(id, { status: status, updatedAt: new Date().toISOString() });
  if (!updated) return jsonResponse({ ok: false, error: 'Submission not found.' });
  return jsonResponse({ ok: true });
}

function updateSubmission_(p) {
  const auth = checkAdmin_(p);
  if (auth) return jsonResponse({ ok: false, error: auth });
  const id = clean_(p.id || '');
  const patch = {
    name: clean_(p.name || 'Anonymous').slice(0, 80) || 'Anonymous',
    email: clean_(p.email || ''),
    category: clean_(p.category || ''),
    title: clean_(p.title || '').slice(0, MAX_TITLE_CHARS),
    reflection: clean_(p.reflection || '').slice(0, MAX_REFLECTION_CHARS),
    updatedAt: new Date().toISOString()
  };
  if (!patch.title) return jsonResponse({ ok: false, error: 'Title is required.' });
  if (ALLOWED_CATEGORIES.indexOf(patch.category) === -1) return jsonResponse({ ok: false, error: 'Invalid category.' });
  const updated = updateRowById_(id, patch);
  if (!updated) return jsonResponse({ ok: false, error: 'Submission not found.' });
  return jsonResponse({ ok: true });
}

function deleteSubmission_(p) {
  const auth = checkAdmin_(p);
  if (auth) return jsonResponse({ ok: false, error: auth });
  const id = clean_(p.id || '');
  const sheet = getOrCreateSheet();
  const info = findRowInfo_(sheet, id);
  if (!info) return jsonResponse({ ok: false, error: 'Submission not found.' });
  const fileId = String(info.item.fileId || '');
  let driveError = '';
  if (fileId) {
    try { DriveApp.getFileById(fileId).setTrashed(true); } catch (err) { driveError = errorText_(err); }
  }
  sheet.deleteRow(info.rowNumber);
  return jsonResponse({ ok: true, driveError: driveError });
}

function setModeration_(p) {
  const auth = checkAdmin_(p);
  if (auth) return jsonResponse({ ok: false, error: auth });
  const enabled = String(p.enabled || '').toLowerCase() === 'true';
  PropertiesService.getScriptProperties().setProperty('MODERATION_ENABLED', String(enabled));
  return jsonResponse({ ok: true, moderationEnabled: enabled });
}

function discussionReplies_(p) {
  const topicId = clean_(p.topicId || '');
  if (!topicId) return jsonResponse({ ok: false, error: 'Topic ID is required.' });
  const rows = readDiscussionRows_().filter(function(item) {
    return item.topicId === topicId && item.status === 'approved';
  });
  rows.sort(function(a, b) { return new Date(a.timestamp) - new Date(b.timestamp); });
  return jsonResponse({ ok: true, replies: rows.map(publicDiscussionShape_) });
}

function submitDiscussionReply_(p) {
  const topicId = clean_(p.topicId || '');
  const topicTitle = clean_(p.topicTitle || '').slice(0, 120);
  const parentId = clean_(p.parentId || '');
  const name = clean_(p.name || 'Anonymous').slice(0, 80) || 'Anonymous';
  const email = clean_(p.email || '').slice(0, 120);
  const text = cleanLong_(p.text || '').slice(0, MAX_DISCUSSION_REPLY_CHARS);
  if (!topicId) return jsonResponse({ ok: false, error: 'Topic ID is required.' });
  if (!text) return jsonResponse({ ok: false, error: 'Reply text is required.' });
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return jsonResponse({ ok: false, error: 'Email must be valid or blank.' });
  const now = new Date();
  const item = {
    id: Utilities.getUuid(),
    timestamp: now.toISOString(),
    status: 'approved',
    topicId: topicId,
    topicTitle: topicTitle,
    parentId: parentId,
    name: name,
    email: email,
    text: text,
    updatedAt: now.toISOString()
  };
  appendDiscussionRow_(item);
  return jsonResponse({ ok: true, id: item.id });
}

function publicDiscussionShape_(item) {
  return {
    id: item.id,
    timestamp: item.timestamp,
    topicId: item.topicId,
    topicTitle: item.topicTitle,
    parentId: item.parentId,
    name: item.name,
    text: item.text
  };
}

function appendDiscussionRow_(item) {
  const sheet = getOrCreateDiscussionSheet_();
  ensureDiscussionHeaders_(sheet);
  sheet.appendRow(DISCUSSION_HEADERS.map(function(h) { return item[h] || ''; }));
}

function readDiscussionRows_() {
  const sheet = getOrCreateDiscussionSheet_();
  ensureDiscussionHeaders_(sheet);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0].map(String);
  return values.slice(1).map(function(row) {
    const obj = {};
    headers.forEach(function(h, i) { obj[h] = row[i] == null ? '' : String(row[i]); });
    return obj;
  }).filter(function(obj) { return obj.id; });
}

function getOrCreateDiscussionSheet_() {
  const props = PropertiesService.getScriptProperties();
  const existingId = props.getProperty('DISCUSSION_SHEET_ID');
  if (existingId) {
    try { return SpreadsheetApp.openById(existingId).getSheets()[0]; } catch (ignore) {}
  }
  const ss = SpreadsheetApp.create(DISCUSSION_SHEET_NAME);
  props.setProperty('DISCUSSION_SHEET_ID', ss.getId());
  const sheet = ss.getSheets()[0];
  sheet.setName('Discussion Replies');
  ensureDiscussionHeaders_(sheet);
  return sheet;
}

function ensureDiscussionHeaders_(sheet) {
  const lastCol = sheet.getLastColumn();
  if (sheet.getLastRow() === 0 || lastCol === 0) {
    sheet.getRange(1, 1, 1, DISCUSSION_HEADERS.length).setValues([DISCUSSION_HEADERS]);
    sheet.setFrozenRows(1);
    return;
  }
  const existing = sheet.getRange(1, 1, 1, Math.max(lastCol, DISCUSSION_HEADERS.length)).getValues()[0].map(String);
  let changed = false;
  DISCUSSION_HEADERS.forEach(function(h) { if (existing.indexOf(h) === -1) { existing.push(h); changed = true; } });
  if (changed || existing.length !== lastCol) sheet.getRange(1, 1, 1, existing.length).setValues([existing]);
  sheet.setFrozenRows(1);
}

function publicShape_(item) {
  return {
    id: item.id,
    timestamp: item.timestamp,
    category: item.category,
    title: item.title,
    reflection: item.reflection,
    fileName: item.fileName,
    mimeType: item.mimeType,
    fileId: item.fileId,
    fileUrl: item.fileUrl,
    textContent: item.textContent,
    name: item.name
  };
}

function appendRow_(item) {
  const sheet = getOrCreateSheet();
  ensureHeaders(sheet);
  sheet.appendRow(HEADERS.map(function(h) { return item[h] || ''; }));
}

function readRows_() {
  const sheet = getOrCreateSheet();
  ensureHeaders(sheet);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];
  const headers = values[0].map(String);
  return values.slice(1).map(function(row) {
    const obj = {};
    headers.forEach(function(h, i) { obj[h] = row[i] == null ? '' : String(row[i]); });
    return obj;
  }).filter(function(obj) { return obj.id; });
}

function updateRowById_(id, patch) {
  const sheet = getOrCreateSheet();
  const info = findRowInfo_(sheet, id);
  if (!info) return false;
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  Object.keys(patch).forEach(function(key) {
    const col = headers.indexOf(key) + 1;
    if (col > 0) sheet.getRange(info.rowNumber, col).setValue(patch[key]);
  });
  return true;
}

function findRowInfo_(sheet, id) {
  ensureHeaders(sheet);
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) return null;
  const headers = values[0].map(String);
  const idCol = headers.indexOf('id');
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][idCol]) === id) {
      const item = {};
      headers.forEach(function(h, j) { item[h] = values[i][j] == null ? '' : String(values[i][j]); });
      return { rowNumber: i + 1, item: item };
    }
  }
  return null;
}

function getOrCreateSheet() {
  const props = PropertiesService.getScriptProperties();
  const existingId = props.getProperty('SHEET_ID');
  if (existingId) {
    try { return SpreadsheetApp.openById(existingId).getSheets()[0]; } catch (ignore) {}
  }
  const ss = SpreadsheetApp.create(SHEET_NAME);
  props.setProperty('SHEET_ID', ss.getId());
  const sheet = ss.getSheets()[0];
  sheet.setName('Submissions');
  ensureHeaders(sheet);
  return sheet;
}

function ensureHeaders(sheet) {
  const lastCol = sheet.getLastColumn();
  if (sheet.getLastRow() === 0 || lastCol === 0) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
    sheet.setFrozenRows(1);
    return;
  }
  const existing = sheet.getRange(1, 1, 1, Math.max(lastCol, HEADERS.length)).getValues()[0].map(String);
  let changed = false;
  HEADERS.forEach(function(h) { if (existing.indexOf(h) === -1) { existing.push(h); changed = true; } });
  if (changed || existing.length !== lastCol) sheet.getRange(1, 1, 1, existing.length).setValues([existing]);
  sheet.setFrozenRows(1);
}

function getOrCreateRootFolder() {
  const props = PropertiesService.getScriptProperties();
  const folderId = props.getProperty('ROOT_FOLDER_ID');
  if (folderId) {
    try { return DriveApp.getFolderById(folderId); } catch (ignore) {}
  }
  const folder = DriveApp.createFolder(PROJECT_NAME);
  props.setProperty('ROOT_FOLDER_ID', folder.getId());
  return folder;
}

function getOrCreateCategoryFolder(category) {
  const root = getOrCreateRootFolder();
  const iter = root.getFoldersByName(category);
  if (iter.hasNext()) return iter.next();
  return root.createFolder(category);
}

function isModerationEnabled_() {
  const value = PropertiesService.getScriptProperties().getProperty('MODERATION_ENABLED');
  if (value === null || value === '') return true;
  return String(value).toLowerCase() !== 'false';
}

function getAdminPasscode_() {
  return String(PropertiesService.getScriptProperties().getProperty('ADMIN_PASSCODE') || '').trim();
}

function checkAdmin_(p) {
  const configured = getAdminPasscode_();
  if (!configured) return 'Admin passcode not configured.';
  const supplied = String(p.passcode || '').trim();
  if (supplied !== configured) return 'Invalid passcode.';
  return '';
}

function clean_(value) {
  return String(value == null ? '' : value).replace(/[\u0000-\u001F\u007F]/g, ' ').replace(/\s+/g, ' ').trim();
}

function cleanLong_(value) {
  return String(value == null ? '' : value).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ' ').replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
}

function sanitize_(value) {
  return String(value || 'file').replace(/[^a-z0-9._-]+/gi, '-').replace(/-+/g, '-').slice(0, 80) || 'file';
}

function errorText_(err) {
  return String(err && err.message ? err.message : err);
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
