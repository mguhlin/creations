/**
 * ImageBoard Google Drive + Sheets backend
 * 1. Create a Google Sheet named "ImageBoard Saves".
 * 2. Open Extensions > Apps Script and paste this file.
 * 3. Deploy > New deployment > Web app.
 * 4. Execute as: Me. Access: your preferred audience.
 */
const CONFIG = {
  rootFolderName: 'ImageBoard Saves',
  sheetName: 'ImageBoard Saves'
};

function doGet(e) {
  try {
    const action = (e.parameter.action || '').toLowerCase();
    if (action === 'load') return json(loadBoard_(e.parameter.boardId));
    if (action === 'list') return json(listBoards_());
    return json({ ok: true, message: 'ImageBoard backend is running.' });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents || '{}');
    if (payload.action === 'save') return json(saveBoard_(payload.board, payload.png));
    return json({ ok: false, error: 'Unknown action.' });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function saveBoard_(board, pngDataUrl) {
  if (!board || !board.title) throw new Error('Missing board data.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const boardId = board.boardId || Utilities.getUuid();
  board.boardId = boardId;
  board.updatedAt = new Date().toISOString();
  const folder = getOrCreateFolder_(safeName_(board.title) + ' - ' + boardId, root);

  const jsonBlob = Utilities.newBlob(JSON.stringify(board, null, 2), 'application/json', 'board.imageboard.json');
  const jsonFile = upsertFile_(folder, 'board.imageboard.json', jsonBlob);

  let pngFile = null;
  if (pngDataUrl && pngDataUrl.indexOf('base64,') > -1) {
    const bytes = Utilities.base64Decode(pngDataUrl.split('base64,')[1]);
    const pngBlob = Utilities.newBlob(bytes, 'image/png', 'board-preview.png');
    pngFile = upsertFile_(folder, 'board-preview.png', pngBlob);
  }

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.sheetName);
  ensureHeader_(sheet);
  appendOrUpdateRow_(sheet, boardId, [
    boardId,
    board.title || '',
    board.className || '',
    board.panels ? board.panels.length : 0,
    board.updatedAt,
    folder.getUrl(),
    jsonFile.getUrl(),
    pngFile ? pngFile.getUrl() : ''
  ]);

  return { ok: true, boardId, folderUrl: folder.getUrl(), jsonUrl: jsonFile.getUrl(), pngUrl: pngFile ? pngFile.getUrl() : '' };
}

function loadBoard_(boardId) {
  if (!boardId) throw new Error('Missing boardId.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const folders = root.getFolders();
  while (folders.hasNext()) {
    const folder = folders.next();
    if (folder.getName().endsWith(boardId)) {
      const files = folder.getFilesByName('board.imageboard.json');
      if (!files.hasNext()) throw new Error('Board JSON not found.');
      const board = JSON.parse(files.next().getBlob().getDataAsString());
      return { ok: true, board };
    }
  }
  throw new Error('Board not found.');
}

function listBoards_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.sheetName);
  ensureHeader_(sheet);
  const values = sheet.getDataRange().getValues();
  const rows = values.slice(1).map(r => ({ boardId: r[0], title: r[1], className: r[2], panels: r[3], updatedAt: r[4], folderUrl: r[5], jsonUrl: r[6], pngUrl: r[7] }));
  return { ok: true, boards: rows };
}

function getOrCreateFolder_(name, parent) {
  const container = parent || DriveApp;
  const folders = container.getFoldersByName(name);
  return folders.hasNext() ? folders.next() : container.createFolder(name);
}

function upsertFile_(folder, name, blob) {
  const files = folder.getFilesByName(name);
  while (files.hasNext()) files.next().setTrashed(true);
  return folder.createFile(blob);
}

function getOrCreateSheet_(ss, name) {
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function ensureHeader_(sheet) {
  const header = ['boardId', 'title', 'className', 'panels', 'updatedAt', 'folderUrl', 'jsonUrl', 'pngUrl'];
  if (sheet.getLastRow() === 0) sheet.appendRow(header);
}

function appendOrUpdateRow_(sheet, boardId, row) {
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === boardId) {
      sheet.getRange(i + 1, 1, 1, row.length).setValues([row]);
      return;
    }
  }
  sheet.appendRow(row);
}

function safeName_(name) {
  return String(name || 'ImageBoard').replace(/[\\/:*?"<>|#%{}~&]/g, '-').slice(0, 80);
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
