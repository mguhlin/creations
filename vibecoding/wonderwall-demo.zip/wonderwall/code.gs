/**
 * WonderWall — Moderated Question Wall
 * Google Apps Script Web App backend
 *
 * Static files expected:
 * - index.html  public approved question wall
 * - Submit.html public anonymous question form
 * - Admin.html  passcode-protected moderation console
 */

const PROJECT_NAME = 'WonderWall';
const SHEET_NAME = 'WonderWall Questions';
const MAX_QUESTION_CHARS = 280;
const MAX_CONTEXT_CHARS = 300;
const MAX_TAG_CHARS = 40;
const ALLOWED_STATUSES = ['pending', 'approved', 'hidden'];

const SHEET_HEADERS = [
  'id',
  'timestamp',
  'question',
  'context',
  'tag',
  'status',
  'answered',
  'upvotes',
  'adminNote',
  'lastUpdated'
];

function doGet(e) {
  const p = (e && e.parameter) || {};
  const action = String(p.action || 'list');

  try {
    if (action === 'ping') {
      return jsonResponse({
        ok: true,
        project: PROJECT_NAME,
        sheet: SHEET_NAME,
        passcodeSet: Boolean(PropertiesService.getScriptProperties().getProperty('ADMIN_PASSCODE')),
        time: new Date().toISOString()
      });
    }

    if (action === 'list') {
      const includeAnswered = String(p.includeAnswered || 'true') === 'true';
      let questions = readSheet(getOrCreateSheet()).filter(function (q) {
        return q.id && q.status === 'approved';
      });
      if (!includeAnswered) {
        questions = questions.filter(function (q) { return String(q.answered) !== 'true'; });
      }
      questions = questions.map(publicQuestion).reverse();
      return jsonResponse({ ok: true, questions: questions });
    }

    return jsonResponse({ ok: false, error: 'Unknown action.' });
  } catch (err) {
    return jsonResponse({ ok: false, error: errorMessage(err) });
  }
}

function doPost(e) {
  const p = (e && e.parameter) || {};
  const action = String(p.action || 'submit');

  try {
    if (action === 'submit') return submitQuestion(p);
    if (action === 'adminList') return adminList(p);
    if (action === 'approve') return adminSetStatus(p, 'approved');
    if (action === 'hide') return adminSetStatus(p, 'hidden');
    if (action === 'restore') return adminSetStatus(p, 'pending');
    if (action === 'delete') return adminDelete(p);
    if (action === 'toggleAnswered') return adminToggleAnswered(p);
    if (action === 'update') return adminUpdate(p);
    if (action === 'upvote') return upvoteQuestion(p);

    return jsonResponse({ ok: false, error: 'Unknown action.' });
  } catch (err) {
    return jsonResponse({ ok: false, error: errorMessage(err) });
  }
}

function submitQuestion(p) {
  let question = cleanText(p.question || '');
  let context = cleanText(p.context || '');
  let tag = cleanText(p.tag || 'General');

  if (!question) return jsonResponse({ ok: false, error: 'Question is required.' });
  if (question.length > MAX_QUESTION_CHARS) question = question.slice(0, MAX_QUESTION_CHARS);
  if (context.length > MAX_CONTEXT_CHARS) context = context.slice(0, MAX_CONTEXT_CHARS);
  if (tag.length > MAX_TAG_CHARS) tag = tag.slice(0, MAX_TAG_CHARS);
  if (!tag) tag = 'General';

  const now = new Date();
  const row = {
    id: Utilities.getUuid(),
    timestamp: now.toISOString(),
    question: question,
    context: context,
    tag: tag,
    status: 'pending',
    answered: 'false',
    upvotes: 0,
    adminNote: '',
    lastUpdated: now.toISOString()
  };

  appendRow(getOrCreateSheet(), row);
  return jsonResponse({ ok: true, id: row.id, status: 'pending' });
}

function upvoteQuestion(p) {
  const id = String(p.id || '').trim();
  if (!id) return jsonResponse({ ok: false, error: 'Missing question id.' });

  const sheet = getOrCreateSheet();
  const found = findRowById(sheet, id);
  if (!found) return jsonResponse({ ok: false, error: 'Question not found.' });

  const statusCol = found.headers.indexOf('status') + 1;
  const upvotesCol = found.headers.indexOf('upvotes') + 1;
  const updatedCol = found.headers.indexOf('lastUpdated') + 1;
  const status = String(sheet.getRange(found.rowIndex, statusCol).getValue());
  if (status !== 'approved') return jsonResponse({ ok: false, error: 'Only approved questions can be upvoted.' });

  const current = Number(sheet.getRange(found.rowIndex, upvotesCol).getValue() || 0);
  sheet.getRange(found.rowIndex, upvotesCol).setValue(current + 1);
  sheet.getRange(found.rowIndex, updatedCol).setValue(new Date().toISOString());

  return jsonResponse({ ok: true, upvotes: current + 1 });
}

function adminList(p) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });
  const questions = readSheet(getOrCreateSheet()).filter(function (q) { return q.id; }).reverse();
  return jsonResponse({ ok: true, questions: questions });
}

function adminSetStatus(p, status) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });
  if (ALLOWED_STATUSES.indexOf(status) === -1) return jsonResponse({ ok: false, error: 'Invalid status.' });

  const id = String(p.id || '').trim();
  if (!id) return jsonResponse({ ok: false, error: 'Missing question id.' });

  const sheet = getOrCreateSheet();
  const found = findRowById(sheet, id);
  if (!found) return jsonResponse({ ok: false, error: 'Question not found.' });

  setCell(sheet, found, 'status', status);
  setCell(sheet, found, 'lastUpdated', new Date().toISOString());
  return jsonResponse({ ok: true, id: id, status: status });
}

function adminToggleAnswered(p) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });

  const id = String(p.id || '').trim();
  const answered = String(p.answered || 'false') === 'true' ? 'true' : 'false';
  if (!id) return jsonResponse({ ok: false, error: 'Missing question id.' });

  const sheet = getOrCreateSheet();
  const found = findRowById(sheet, id);
  if (!found) return jsonResponse({ ok: false, error: 'Question not found.' });

  setCell(sheet, found, 'answered', answered);
  setCell(sheet, found, 'lastUpdated', new Date().toISOString());
  return jsonResponse({ ok: true, id: id, answered: answered });
}

function adminUpdate(p) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });

  const id = String(p.id || '').trim();
  if (!id) return jsonResponse({ ok: false, error: 'Missing question id.' });

  let question = cleanText(p.question || '');
  let context = cleanText(p.context || '');
  let tag = cleanText(p.tag || 'General');
  let adminNote = cleanText(p.adminNote || '');

  if (!question) return jsonResponse({ ok: false, error: 'Question cannot be blank.' });
  if (question.length > MAX_QUESTION_CHARS) question = question.slice(0, MAX_QUESTION_CHARS);
  if (context.length > MAX_CONTEXT_CHARS) context = context.slice(0, MAX_CONTEXT_CHARS);
  if (tag.length > MAX_TAG_CHARS) tag = tag.slice(0, MAX_TAG_CHARS);
  if (!tag) tag = 'General';

  const sheet = getOrCreateSheet();
  const found = findRowById(sheet, id);
  if (!found) return jsonResponse({ ok: false, error: 'Question not found.' });

  setCell(sheet, found, 'question', question);
  setCell(sheet, found, 'context', context);
  setCell(sheet, found, 'tag', tag);
  setCell(sheet, found, 'adminNote', adminNote);
  setCell(sheet, found, 'lastUpdated', new Date().toISOString());
  return jsonResponse({ ok: true, id: id });
}

function adminDelete(p) {
  const authError = checkAdminAuth(p);
  if (authError) return jsonResponse({ ok: false, error: authError });

  const id = String(p.id || '').trim();
  if (!id) return jsonResponse({ ok: false, error: 'Missing question id.' });

  const sheet = getOrCreateSheet();
  const found = findRowById(sheet, id);
  if (!found) return jsonResponse({ ok: false, error: 'Question not found.' });

  sheet.deleteRow(found.rowIndex);
  return jsonResponse({ ok: true, id: id });
}

function publicQuestion(q) {
  return {
    id: q.id,
    timestamp: q.timestamp,
    question: q.question,
    context: q.context,
    tag: q.tag || 'General',
    answered: String(q.answered) === 'true',
    upvotes: Number(q.upvotes || 0)
  };
}

function checkAdminAuth(p) {
  const configured = String(PropertiesService.getScriptProperties().getProperty('ADMIN_PASSCODE') || '');
  if (!configured) return 'Admin passcode not configured.';
  const provided = String(p.passcode || '');
  if (provided !== configured) return 'Invalid passcode.';
  return null;
}

function getOrCreateSheet() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('WONDERWALL_SHEET_ID');
  let ss;

  if (id) {
    try { ss = SpreadsheetApp.openById(id); } catch (err) { ss = null; }
  }

  if (!ss) {
    ss = SpreadsheetApp.create(SHEET_NAME);
    props.setProperty('WONDERWALL_SHEET_ID', ss.getId());
  }

  let sheet = ss.getSheetByName('Questions');
  if (!sheet) sheet = ss.insertSheet('Questions');

  ensureHeaders(sheet);
  return sheet;
}

function ensureHeaders(sheet) {
  const current = getHeaders(sheet);
  if (current.length === 0) {
    sheet.appendRow(SHEET_HEADERS);
    sheet.getRange(1, 1, 1, SHEET_HEADERS.length).setFontWeight('bold');
    sheet.setFrozenRows(1);
    return;
  }

  SHEET_HEADERS.forEach(function (h) {
    if (current.indexOf(h) === -1) {
      sheet.getRange(1, sheet.getLastColumn() + 1).setValue(h).setFontWeight('bold');
    }
  });
}

function getHeaders(sheet) {
  if (sheet.getLastRow() === 0) return [];
  return sheet.getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1)).getValues()[0].map(String);
}

function readSheet(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const headers = getHeaders(sheet);
  const values = sheet.getRange(2, 1, lastRow - 1, headers.length).getValues();
  return values.map(function (row) {
    const obj = {};
    headers.forEach(function (h, i) { obj[h] = row[i]; });
    return obj;
  });
}

function appendRow(sheet, obj) {
  const headers = getHeaders(sheet);
  const row = headers.map(function (h) { return obj[h] !== undefined ? obj[h] : ''; });
  sheet.appendRow(row);
}

function findRowById(sheet, id) {
  const headers = getHeaders(sheet);
  const idCol = headers.indexOf('id') + 1;
  if (idCol < 1 || sheet.getLastRow() < 2) return null;

  const ids = sheet.getRange(2, idCol, sheet.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === id) {
      return { rowIndex: i + 2, headers: headers };
    }
  }
  return null;
}

function setCell(sheet, found, header, value) {
  const col = found.headers.indexOf(header) + 1;
  if (col < 1) throw new Error('Missing column: ' + header);
  sheet.getRange(found.rowIndex, col).setValue(value);
}

function cleanText(value) {
  return String(value || '')
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function errorMessage(err) {
  return String(err && err.message ? err.message : err);
}

function setupNow() {
  getOrCreateSheet();
  return 'WonderWall setup complete. Add ADMIN_PASSCODE in Script Properties, then deploy as a Web App.';
}
