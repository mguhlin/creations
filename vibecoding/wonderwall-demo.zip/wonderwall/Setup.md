# WonderWall Setup

WonderWall is a moderated question wall for classrooms, workshops, staff meetings, and professional development. Participants submit questions anonymously. A teacher, facilitator, or moderator approves questions before they appear on the public wall.

Use it as a free, self-hosted alternative to Slido or Mentimeter Q&A.

## What's in this folder

| File | Purpose |
|---|---|
| `code.gs` | Google Apps Script backend. Stores questions in a Google Sheet. |
| `index.html` | Public question wall. Shows approved questions only. |
| `Submit.html` | Anonymous question submission form. Links back to the wall. |
| `Admin.html` | Passcode-protected moderation page. |

## How WonderWall works

1. A participant opens `Submit.html` and submits a question.
2. The question is saved to a Google Sheet with the status `pending`.
3. The moderator opens `Admin.html`, enters the admin passcode, and approves, edits, hides, marks answered, or deletes questions.
4. `index.html` displays only questions with the status `approved`.

Public visitors cannot see pending or hidden questions.

## Step 1 — Create the Apps Script project

1. Go to [script.google.com](https://script.google.com) and click **New project**.
2. Rename the project, for example: `WonderWall`.
3. Delete the placeholder code in `Code.gs`.
4. Paste in the contents of `code.gs` from this folder.
5. Save the project.

## Step 2 — Run setupNow once

1. In the function dropdown at the top of the Apps Script editor, select `setupNow`.
2. Click **Run**.
3. Authorize the script when prompted.
4. If Google says the app is not verified, choose **Advanced** > **Go to project name** > **Allow**.

This creates a Google Sheet named `WonderWall Questions` with a `Questions` tab.

## Step 3 — Set the admin passcode

1. In Apps Script, click the gear icon for **Project Settings**.
2. Scroll to **Script Properties**.
3. Click **Edit script properties**.
4. Add this property:

| Property | Value |
|---|---|
| `ADMIN_PASSCODE` | Choose your own passcode |

5. Save.

If this is skipped, the public submission form and board can still work, but `Admin.html` will not allow moderation.

## Step 4 — Deploy as a web app

1. Click **Deploy** > **New deployment**.
2. Click the gear next to **Select type** and choose **Web app**.
3. Use these settings:

| Setting | Value |
|---|---|
| Description | `v1` or another label |
| Execute as | **Me** |
| Who has access | **Anyone** |

4. Click **Deploy**.
5. Authorize again if asked.
6. Copy the **Web app URL**. It ends in `/exec`.

The **Anyone** setting is required so participants can submit questions without signing into Google.

## Step 5 — Run a quick health check

Paste your Web app URL into a browser and add this to the end:

```text
?action=ping
```

Example:

```text
https://script.google.com/macros/s/AKfy.../exec?action=ping
```

You should see a JSON response like this:

```json
{
  "ok": true,
  "project": "WonderWall",
  "sheet": "WonderWall Questions",
  "passcodeSet": true,
  "time": "2026-05-01T..."
}
```

If `passcodeSet` is `false`, return to Step 3.

## Step 6 — Paste the Web App URL into the HTML files

Open these three files:

- `index.html`
- `Submit.html`
- `Admin.html`

Find this line near the bottom of each file:

```javascript
const SCRIPT_URL = 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE';
```

Replace the placeholder with your Apps Script Web App URL.

Example:

```javascript
const SCRIPT_URL = 'https://script.google.com/macros/s/AKfy.../exec';
```

Save all three HTML files.

## Step 7 — Host the static files

Keep these files together in the same folder:

- `index.html`
- `Submit.html`
- `Admin.html`

The files use relative links, so the names matter.

Suggested hosting options:

- GitHub Pages
- WordPress static folder or media area
- Google Drive-hosted static site workaround
- Any standard web host

For embedding in a website, use an iframe:

```html
<iframe src="https://yourdomain.com/path/to/wonderwall/Submit.html"
        width="100%"
        height="900"
        frameborder="0"
        style="border: none;"></iframe>
```

Suggested iframe heights:

| Page | Suggested height |
|---|---:|
| `Submit.html` | 850–1000 |
| `index.html` | 1000–1600 |
| `Admin.html` | Use as a standalone private page |

## Step 8 — Test the workflow

1. Open `Submit.html`.
2. Submit a test question.
3. Open `Admin.html`.
4. Enter the admin passcode.
5. Approve the question.
6. Open `index.html`.
7. Confirm the approved question appears.
8. In `Admin.html`, mark it answered, hide it, restore it to pending, and delete it to confirm all controls work.

## Digital citizenship reminder

Both `index.html` and `Submit.html` include a linked **Digital Citizenship Reminder**. It reminds students and staff that WonderWall is anonymous to the public, but still part of the learning environment.

The reminder says participants should:

- Ask questions that help the group learn.
- Avoid names, private information, insults, jokes at someone’s expense, or harmful language.
- Use a professional tone.
- Follow campus, district, classroom, or workshop expectations.
- Understand that the moderator may edit, hide, or delete submissions.

You may revise this language to match your district’s acceptable use policy or classroom norms.

## Updating `code.gs` later

If you change `code.gs` after deployment, you must redeploy the web app as a new version.

1. Click **Deploy** > **Manage deployments**.
2. Click the pencil icon on the current deployment.
3. Under **Version**, choose **New version**.
4. Click **Deploy**.

The Web App URL usually stays the same. The HTML files do not need to be changed unless you create a brand-new deployment URL.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `Backend not configured` | The Apps Script URL was not pasted into the HTML file. | Replace `PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE` in all three HTML files. |
| `Admin passcode not configured` | `ADMIN_PASSCODE` is missing from Script Properties. | Add the property in Apps Script Project Settings. |
| `Invalid passcode` | Wrong passcode or extra spaces. | Recheck Script Properties and type the passcode exactly. |
| Submitted questions do not appear on the wall | They are still pending. | Approve them in `Admin.html`. |
| The wall loads but is empty | No approved questions exist yet. | Submit and approve a test question. |
| Browser shows an HTML error instead of JSON | Web app access is not set to Anyone. | Redeploy as a Web App with access set to Anyone. |
| You edited `code.gs`, but nothing changed | The web app is still running the old version. | Redeploy as a new version. |

## Privacy and moderation notes

- WonderWall does not collect participant names or email addresses.
- Questions are anonymous on the public board.
- Questions are stored in a Google Sheet owned by the Apps Script project owner.
- The moderator can edit question wording before approval.
- The moderator can hide or delete inappropriate questions.
- This is not a high-security anonymous reporting system. It is a lightweight classroom and workshop Q&A tool.

## Suggested classroom launch script

> Use WonderWall to ask questions that help our group learn. You do not need to include your name. Keep questions respectful, clear, and connected to our topic. Questions appear publicly only after I approve them.
