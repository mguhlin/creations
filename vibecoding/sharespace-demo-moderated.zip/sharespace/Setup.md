# ShareSpace Setup

ShareSpace is a free, self-hosted submission gallery for classrooms, workshops, staff PD, and student showcases. Participants upload a file, choose a category, and add a short reflection. A facilitator can run it as an open gallery or turn on moderation so submissions must be approved before appearing publicly.

This version follows the same organization as WonderWall and StickyBoard:

| File | Purpose |
|---|---|
| `code.gs` | Google Apps Script backend. Stores submissions in a Google Sheet and files in Google Drive. |
| `index.html` | Public ShareSpace gallery. Replaces the older `board.html`. |
| `Submit.html` | Participant upload form. Links back to the gallery and digital citizenship reminder. |
| `Admin.html` | Password-protected moderation panel. Approve, hide, restore, edit, delete, and toggle moderation. |
| `Setup.md` | These setup instructions. |

## What changed from the older ShareSpace demo

- `board.html` is now `index.html` to match the newer WonderWall and StickyBoard pattern.
- Submissions can be **moderated** or **open**.
- When moderation is ON, new submissions are saved as `pending` until approved.
- When moderation is OFF, new submissions appear on the public gallery immediately.
- Admin can approve, hide, restore, edit metadata/reflections, and delete submissions.
- Public pages include linked digital citizenship guidance.
- Public display hides participant email addresses.

## Default categories

The files ship with these categories:

- Amazing Prompts
- Gemini Images
- ChatGPT Images
- Claude Images
- Student Projects
- Staff Examples
- Miscellaneous

To change them, update the category list in:

- `code.gs` — `ALLOWED_CATEGORIES`
- `Submit.html` — the `<select id="category">` options
- `index.html` — the `CATEGORIES` constant
- `Admin.html` — the `CATEGORIES` constant

The names must match exactly.

## Step 1 — Create the Apps Script project

1. Go to [script.google.com](https://script.google.com).
2. Click **New project**.
3. Rename the project, such as `ShareSpace Moderated`.
4. Delete the starter code in `Code.gs`.
5. Paste in the contents of `code.gs` from this folder.
6. Save.

## Step 2 — Run setupNow once

1. In Apps Script, choose `setupNow` from the function dropdown.
2. Click **Run**.
3. Authorize the script.
4. Check Google Drive for a folder named `ShareSpace` and a Google Sheet named `ShareSpace Submissions`.

The script creates category folders automatically.

## Step 3 — Set the admin passcode

1. Open **Project Settings** in Apps Script.
2. Under **Script Properties**, click **Edit script properties**.
3. Add this property:

```text
ADMIN_PASSCODE
```

4. Set its value to a passcode you choose.
5. Save.

Optional property:

```text
MODERATION_ENABLED
```

Set it to `true` or `false`. If you skip this, moderation defaults to `true`. You can also toggle moderation from `Admin.html` after deployment.

## Step 4 — Deploy as a web app

1. Click **Deploy** > **New deployment**.
2. Select **Web app**.
3. Use these settings:
   - **Execute as:** Me
   - **Who has access:** Anyone
4. Click **Deploy**.
5. Copy the Web app URL. It ends in `/exec`.

## Step 5 — Test the backend

Open your Web app URL with this added to the end:

```text
?action=ping
```

Example:

```text
https://script.google.com/macros/s/AKfy.../exec?action=ping
```

You should see JSON with `ok:true`, the category list, moderation status, and whether the passcode is set.

## Step 6 — Paste the Apps Script URL into the HTML files

In these three files:

- `index.html`
- `Submit.html`
- `Admin.html`

Find:

```javascript
const SCRIPT_URL = 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE';
```

Replace the placeholder with your Apps Script Web App URL.

## Step 7 — Host the static files

Keep these files in the same folder:

- `index.html`
- `Submit.html`
- `Admin.html`

You can host them on GitHub Pages, WordPress, Google Sites embed, or any static web host.

Use `index.html` as the public gallery URL.

## Step 8 — Test the workflow

1. Open `Submit.html`.
2. Submit a test item with a small file.
3. If moderation is ON, open `Admin.html`, enter the passcode, and approve it.
4. Open `index.html` and confirm the item appears.
5. Try hiding, restoring, editing, and deleting from the admin panel.
6. Toggle moderation OFF and submit another test item. It should appear immediately.

## Digital citizenship guidance

ShareSpace is designed for learning spaces. Participants should:

- Submit their own work or work they have permission to share.
- Avoid private information, faces, student IDs, addresses, phone numbers, or sensitive records.
- Use respectful language.
- Choose files appropriate for the classroom, campus, district, or workshop.
- Understand that the facilitator may edit, hide, or delete submissions.

## Troubleshooting

| Problem | Likely fix |
|---|---|
| Public gallery says backend is not configured | Paste the Web App URL into `SCRIPT_URL` in each HTML file. |
| Submit fails | Confirm deployment access is set to **Anyone** and redeploy as a new version. |
| Admin says invalid passcode | Check the `ADMIN_PASSCODE` script property for typos or extra spaces. |
| New `code.gs` changes are not live | Apps Script requires **Deploy > Manage deployments > Edit > New version > Deploy**. |
| Category rejected | Make sure category names match in all files. |
| File preview does not load | Some Google Workspace domains block public Drive previews. The Open button should still work for users with access. |
| Large file fails | The default file limit is 25 MB. Lower it if your environment has slow upload speeds. |

## Notes

- Uploaded files are stored in Google Drive.
- Submission metadata is stored in Google Sheets.
- Deleting from admin moves Drive files to trash and deletes the Sheet row.
- Email addresses are visible only in the admin panel, not on the public gallery.
