/**
 * DrawSplat Google Drive + Sheets backend
 * 1. Create a Google Sheet named "DrawSplat Saves".
 * 2. Open Extensions > Apps Script and paste this file.
 * 3. Deploy > New deployment > Web app.
 * 4. Execute as: Me. Access: your preferred audience.
 */
const CONFIG = {
  rootFolderName: 'DrawSplat Saves',
  roomFolderName: 'DrawSplat Rooms',
  templateFolderName: 'DrawSplat Templates',
  turnInFolderName: 'DrawSplat Turn-Ins',
  sheetName: 'DrawSplat Saves',
  roomSheetName: 'DrawSplat Rooms',
  templateSheetName: 'DrawSplat Templates',
  turnInSheetName: 'DrawSplat Turn-Ins'
};

function doGet(e) {
  try {
    const action = (e.parameter.action || '').toLowerCase();
    if (action === 'load') return json(loadBoard_(e.parameter.boardId));
    if (action === 'list') return json(listBoards_());
    if (action === 'roomload') return json(loadRoom_(e.parameter.room, e.parameter.since));
    if (action === 'roomlist') return json(listRooms_());
    if (action === 'templatelist') return json(listTemplates_());
    if (action === 'templateload') return json(loadTemplate_(e.parameter.templateId));
    if (action === 'turninlist') return json(listTurnIns_());
    if (action === 'turninload') return json(loadTurnIn_(e.parameter.turninId));
    return json({ ok: true, message: 'DrawSplat backend is running.' });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents || '{}');
    const action = String(payload.action || '').toLowerCase();
    if (action === 'save') return json(saveBoard_(payload.board, payload.png));
    if (action === 'roomsave') return json(saveRoom_(payload.room, payload.board, payload.instanceId));
    if (action === 'templatesave') return json(saveTemplate_(payload.template));
    if (action === 'turninsave') return json(saveTurnIn_(payload.turnin, payload.png));
    return json({ ok: false, error: 'Unknown action.' });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function saveBoard_(board, pngDataUrl) {
  if (!board || !board.title) throw new Error('Missing board data.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const boardId = board.boardId || Utilities.getUuid();
  board.boardId = boardId;
  board.updatedAt = new Date().toISOString();
  const folder = getOrCreateFolder_(safeName_(board.title) + ' - ' + boardId, root);

  const jsonBlob = Utilities.newBlob(JSON.stringify(board, null, 2), 'application/json', 'board.drawsplat.json');
  const jsonFile = upsertFile_(folder, 'board.drawsplat.json', jsonBlob);

  let pngFile = null;
  if (pngDataUrl && pngDataUrl.indexOf('base64,') > -1) {
    const bytes = Utilities.base64Decode(pngDataUrl.split('base64,')[1]);
    pngFile = upsertFile_(folder, 'board-preview.png', Utilities.newBlob(bytes, 'image/png', 'board-preview.png'));
  }

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.sheetName);
  ensureHeader_(sheet, ['boardId', 'title', 'className', 'studentName', 'panels', 'updatedAt', 'folderUrl', 'jsonUrl', 'pngUrl']);
  appendOrUpdateRow_(sheet, boardId, [
    boardId,
    board.title || '',
    board.className || '',
    board.studentName || '',
    board.panels ? board.panels.length : 0,
    board.updatedAt,
    folder.getUrl(),
    jsonFile.getUrl(),
    pngFile ? pngFile.getUrl() : ''
  ]);

  return { ok: true, boardId, folderUrl: folder.getUrl(), jsonUrl: jsonFile.getUrl(), pngUrl: pngFile ? pngFile.getUrl() : '' };
}

function loadBoard_(boardId) {
  if (!boardId) throw new Error('Missing boardId.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const folders = root.getFolders();
  while (folders.hasNext()) {
    const folder = folders.next();
    if (folder.getName().endsWith(boardId)) {
      const files = folder.getFilesByName('board.drawsplat.json');
      if (!files.hasNext()) throw new Error('Board JSON not found.');
      return { ok: true, board: JSON.parse(files.next().getBlob().getDataAsString()) };
    }
  }
  throw new Error('Board not found.');
}

function listBoards_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.sheetName);
  ensureHeader_(sheet, ['boardId', 'title', 'className', 'studentName', 'panels', 'updatedAt', 'folderUrl', 'jsonUrl', 'pngUrl']);
  const values = sheet.getDataRange().getValues();
  const rows = values.slice(1).map(r => ({ boardId: r[0], title: r[1], className: r[2], studentName: r[3], panels: r[4], updatedAt: r[5], folderUrl: r[6], jsonUrl: r[7], pngUrl: r[8] }));
  return { ok: true, boards: rows };
}

function saveRoom_(room, board, instanceId) {
  if (!room) throw new Error('Missing room name.');
  if (!board) throw new Error('Missing board data.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const roomRoot = getOrCreateFolder_(CONFIG.roomFolderName, root);
  const roomFileName = safeName_(room) + '.room.json';
  const updatedAt = new Date().toISOString();
  const payload = { room: room, board: board, updatedAt: updatedAt, instanceId: instanceId || '' };
  upsertFile_(roomRoot, roomFileName, Utilities.newBlob(JSON.stringify(payload, null, 2), 'application/json', roomFileName));

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const roomSheet = getOrCreateSheet_(ss, CONFIG.roomSheetName);
  ensureHeader_(roomSheet, ['room', 'title', 'className', 'panels', 'updatedAt', 'instanceId']);
  appendOrUpdateRow_(roomSheet, room, [room, board.title || '', board.className || '', board.panels ? board.panels.length : 0, updatedAt, instanceId || '']);
  return { ok: true, room: room, updatedAt: updatedAt };
}

function loadRoom_(room, since) {
  if (!room) throw new Error('Missing room name.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const roomRoot = getOrCreateFolder_(CONFIG.roomFolderName, root);
  const roomFileName = safeName_(room) + '.room.json';
  const files = roomRoot.getFilesByName(roomFileName);
  if (!files.hasNext()) return { ok: true, room: room, board: null, updatedAt: '' };
  const payload = JSON.parse(files.next().getBlob().getDataAsString());
  if (since && payload.updatedAt && payload.updatedAt === since) return { ok: true, room: room, board: null, updatedAt: payload.updatedAt, instanceId: payload.instanceId || '' };
  return { ok: true, room: room, board: payload.board, updatedAt: payload.updatedAt || '', instanceId: payload.instanceId || '' };
}

function listRooms_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.roomSheetName);
  ensureHeader_(sheet, ['room', 'title', 'className', 'panels', 'updatedAt', 'instanceId']);
  const values = sheet.getDataRange().getValues();
  const rows = values.slice(1).map(r => ({ room: r[0], title: r[1], className: r[2], panels: r[3], updatedAt: r[4], instanceId: r[5] }));
  return { ok: true, rooms: rows };
}

function saveTemplate_(template) {
  if (!template || !template.name) throw new Error('Missing template data.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const folder = getOrCreateFolder_(CONFIG.templateFolderName, root);
  const templateId = template.templateId || Utilities.getUuid();
  template.templateId = templateId;
  template.updatedAt = new Date().toISOString();
  const fileName = safeName_(template.name) + ' - ' + templateId + '.template.json';
  const file = upsertFile_(folder, fileName, Utilities.newBlob(JSON.stringify(template, null, 2), 'application/json', fileName));

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.templateSheetName);
  ensureHeader_(sheet, ['templateId', 'name', 'updatedAt', 'fileUrl']);
  appendOrUpdateRow_(sheet, templateId, [templateId, template.name || '', template.updatedAt, file.getUrl()]);
  return { ok: true, templateId: templateId, updatedAt: template.updatedAt };
}

function listTemplates_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.templateSheetName);
  ensureHeader_(sheet, ['templateId', 'name', 'updatedAt', 'fileUrl']);
  const values = sheet.getDataRange().getValues();
  return { ok: true, templates: values.slice(1).map(r => ({ templateId: r[0], name: r[1], updatedAt: r[2], fileUrl: r[3] })) };
}

function loadTemplate_(templateId) {
  if (!templateId) throw new Error('Missing templateId.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const folder = getOrCreateFolder_(CONFIG.templateFolderName, root);
  const files = folder.getFiles();
  while (files.hasNext()) {
    const file = files.next();
    if (file.getName().indexOf(templateId) > -1) return { ok: true, template: JSON.parse(file.getBlob().getDataAsString()) };
  }
  throw new Error('Template not found.');
}

function saveTurnIn_(turnin, pngDataUrl) {
  if (!turnin || !turnin.board) throw new Error('Missing turn-in data.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const folder = getOrCreateFolder_(CONFIG.turnInFolderName, root);
  const turninId = turnin.turninId || Utilities.getUuid();
  turnin.turninId = turninId;
  turnin.updatedAt = new Date().toISOString();
  const subFolder = getOrCreateFolder_(safeName_((turnin.studentName || 'Student') + ' - ' + (turnin.title || 'Board')) + ' - ' + turninId, folder);
  const jsonFile = upsertFile_(subFolder, 'turnin.drawsplat.json', Utilities.newBlob(JSON.stringify(turnin, null, 2), 'application/json', 'turnin.drawsplat.json'));
  let pngFile = null;
  if (pngDataUrl && pngDataUrl.indexOf('base64,') > -1) {
    const bytes = Utilities.base64Decode(pngDataUrl.split('base64,')[1]);
    pngFile = upsertFile_(subFolder, 'turnin-preview.png', Utilities.newBlob(bytes, 'image/png', 'turnin-preview.png'));
  }

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.turnInSheetName);
  ensureHeader_(sheet, ['turninId', 'studentName', 'className', 'title', 'updatedAt', 'folderUrl', 'jsonUrl', 'pngUrl']);
  appendOrUpdateRow_(sheet, turninId, [turninId, turnin.studentName || '', turnin.className || '', turnin.title || '', turnin.updatedAt, subFolder.getUrl(), jsonFile.getUrl(), pngFile ? pngFile.getUrl() : '']);
  return { ok: true, turninId: turninId, updatedAt: turnin.updatedAt };
}

function listTurnIns_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getOrCreateSheet_(ss, CONFIG.turnInSheetName);
  ensureHeader_(sheet, ['turninId', 'studentName', 'className', 'title', 'updatedAt', 'folderUrl', 'jsonUrl', 'pngUrl']);
  const values = sheet.getDataRange().getValues();
  return { ok: true, turnins: values.slice(1).map(r => ({ turninId: r[0], studentName: r[1], className: r[2], title: r[3], updatedAt: r[4], folderUrl: r[5], jsonUrl: r[6], pngUrl: r[7] })) };
}

function loadTurnIn_(turninId) {
  if (!turninId) throw new Error('Missing turninId.');
  const root = getOrCreateFolder_(CONFIG.rootFolderName);
  const folder = getOrCreateFolder_(CONFIG.turnInFolderName, root);
  const subFolders = folder.getFolders();
  while (subFolders.hasNext()) {
    const sub = subFolders.next();
    if (sub.getName().indexOf(turninId) > -1) {
      const files = sub.getFilesByName('turnin.drawsplat.json');
      if (!files.hasNext()) throw new Error('Turn-in JSON not found.');
      return { ok: true, turnin: JSON.parse(files.next().getBlob().getDataAsString()) };
    }
  }
  throw new Error('Turn-in not found.');
}

function getOrCreateFolder_(name, parent) {
  const container = parent || DriveApp;
  const folders = container.getFoldersByName(name);
  return folders.hasNext() ? folders.next() : container.createFolder(name);
}

function upsertFile_(folder, name, blob) {
  const files = folder.getFilesByName(name);
  while (files.hasNext()) files.next().setTrashed(true);
  return folder.createFile(blob);
}

function getOrCreateSheet_(ss, name) {
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function ensureHeader_(sheet, header) {
  if (sheet.getLastRow() === 0) sheet.appendRow(header);
}

function appendOrUpdateRow_(sheet, key, row) {
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === key) {
      sheet.getRange(i + 1, 1, 1, row.length).setValues([row]);
      return;
    }
  }
  sheet.appendRow(row);
}

function safeName_(name) {
  return String(name || 'DrawSplat').replace(/[\\/:*?"<>|#%{}~&]/g, '-').slice(0, 80);
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
