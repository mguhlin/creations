# TCEA AI Skills Suite

A collection of purpose-built Claude skills for K–16 educators, plus a branded one-page website showcasing them.

**Live site:** https://[your-username].github.io/tcea-ai-skills/

---

## What's in this repo

```
index.html          ← The one-page showcase website (GitHub Pages entry point)
skills/             ← All skill files, ready to upload to a Claude Project
  blog-writer.skill
  pptx-builder.skill
  infographic-designer.skill
  mermaid-designer.skill
  drawio-xml-builder.skill
  rubric-builder.skill
  lesson-plan-architect.skill
```

---

## The Skills

| Skill | What it does | Output |
|---|---|---|
| **Blog Writer** | Educational blog posts for K–16 audiences — conversational, structured, direct | Markdown / text |
| **PPTX Builder** | Download-ready PowerPoint files via PptxGenJS | `.pptx` |
| **Infographic Designer** | Blueprint-first infographic rendering from raw data or content | PNG |
| **Mermaid Designer** | Flowcharts, sequence diagrams, ER diagrams, Gantt charts with TCEA color theming | Mermaid code |
| **Draw.io XML Builder** | Complete importable mxGraph XML for network maps, org charts, process maps | XML |
| **Rubric Builder** | Analytic, holistic, and single-point rubrics with observable, measurable criteria | Markdown table |
| **Lesson Plan Architect** | Standards-aligned lesson plans with five-phase sequence and differentiation built in | Markdown |

---

## How to use a skill

1. Open [Claude.ai](https://claude.ai) and create or open a **Project**
2. Go to **Project knowledge** and upload the `.skill` file
3. Start a conversation — trigger phrases like *"write a blog post about…"* or *"make me a rubric for…"* activate the skill automatically

---

## How to enable the live site (GitHub Pages)

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Under **Source**, select **Deploy from a branch**
4. Choose **main** branch, **/ (root)** folder
5. Click **Save** — your site will be live at `https://[username].github.io/[repo-name]/` within a minute

---

## Built with

- [Claude](https://claude.ai) — AI skills engine
- [TCEA brand guidelines](https://www.tcea.org) — Navy/Gold color system, DM Serif Display + DM Sans typography
